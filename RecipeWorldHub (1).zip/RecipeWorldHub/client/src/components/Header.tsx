import { useState } from "react";
import { Link } from "wouter";

interface HeaderProps {
  mobileMenuOpen: boolean;
  setMobileMenuOpen: (open: boolean) => void;
}

const Header = ({ mobileMenuOpen, setMobileMenuOpen }: HeaderProps) => {
  const [searchQuery, setSearchQuery] = useState("");

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    // Search functionality can be implemented here
    console.log("Searching for:", searchQuery);
  };

  return (
    <>
      <header className="bg-dark text-light py-4 px-6 sticky top-0 z-30 shadow-md">
        <div className="container mx-auto flex justify-between items-center">
          <Link href="/" className="flex items-center space-x-2">
            <span className="text-primary text-3xl">
              <i className="ri-restaurant-line"></i>
            </span>
            <span className="font-heading text-2xl font-bold">FlavorJourney</span>
          </Link>
          
          <div className="hidden md:flex items-center space-x-6">
            <Link href="/" className="font-body hover:text-primary transition">Home</Link>
            <a href="#cuisines" className="font-body hover:text-primary transition">Cuisines</a>
            <Link href="#" className="font-body hover:text-primary transition">Favorites</Link>
            <Link href="#" className="font-body hover:text-primary transition">About</Link>
            
            <form onSubmit={handleSearch} className="relative">
              <input 
                type="text" 
                placeholder="Search recipes..." 
                className="py-1 px-3 pl-8 rounded-full text-dark font-body text-sm focus:outline-none focus:ring-2 focus:ring-primary"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
              <i className="ri-search-line absolute left-2 top-1/2 transform -translate-y-1/2 text-gray-500"></i>
            </form>
          </div>
          
          <button 
            className="md:hidden text-2xl" 
            onClick={() => setMobileMenuOpen(true)}
          >
            <i className="ri-menu-line"></i>
          </button>
        </div>
      </header>
      
      {/* Mobile Menu */}
      <div className={`fixed inset-0 bg-dark bg-opacity-95 z-40 transform transition-transform duration-300 md:hidden ${mobileMenuOpen ? 'translate-x-0' : 'translate-x-full'}`}>
        <div className="flex justify-end p-6">
          <button 
            className="text-light text-3xl"
            onClick={() => setMobileMenuOpen(false)}
          >
            <i className="ri-close-line"></i>
          </button>
        </div>
        
        <div className="flex flex-col items-center space-y-6 mt-10 text-light font-body text-xl">
          <Link href="/" onClick={() => setMobileMenuOpen(false)} className="hover:text-primary transition">Home</Link>
          <a href="#cuisines" onClick={() => setMobileMenuOpen(false)} className="hover:text-primary transition">Cuisines</a>
          <Link href="#" onClick={() => setMobileMenuOpen(false)} className="hover:text-primary transition">Favorites</Link>
          <Link href="#" onClick={() => setMobileMenuOpen(false)} className="hover:text-primary transition">About</Link>
          
          <form onSubmit={handleSearch} className="relative w-3/4 mt-4">
            <input 
              type="text" 
              placeholder="Search recipes..." 
              className="w-full py-2 px-4 pl-10 rounded-full text-dark font-body focus:outline-none focus:ring-2 focus:ring-primary"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
            <i className="ri-search-line absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500"></i>
          </form>
        </div>
      </div>
    </>
  );
};

export default Header;
