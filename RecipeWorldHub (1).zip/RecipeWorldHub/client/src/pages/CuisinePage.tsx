import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { Link, useParams, useLocation } from "wouter";
import { Skeleton } from "@/components/ui/skeleton";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { Recipe } from "@shared/schema";

const CuisinePage = () => {
  const { id } = useParams<{ id: string }>();
  const [, setLocation] = useLocation();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const cuisineId = parseInt(id);

  const { data: cuisine, isLoading: cuisineLoading, isError: cuisineError } = useQuery({
    queryKey: ['/api/cuisines', cuisineId],
    queryFn: async () => {
      const response = await fetch(`/api/cuisines/${cuisineId}`, {
        credentials: 'include',
      });
      if (!response.ok) {
        throw new Error('Failed to fetch cuisine');
      }
      return response.json();
    },
    enabled: !!cuisineId && !isNaN(cuisineId),
    retry: 1,
  });

  const { data: recipes = [], isLoading: recipesLoading, isError: recipesError } = useQuery<Recipe[]>({
    queryKey: ['/api/recipes', cuisineId],
    queryFn: async () => {
      const response = await fetch(`/api/recipes?cuisineId=${cuisineId}`, {
        credentials: 'include',
      });
      if (!response.ok) {
        throw new Error('Failed to fetch recipes');
      }
      return response.json();
    },
    enabled: !!cuisineId && !isNaN(cuisineId),
    retry: 1,
  });

  // Formats a rating from 0-50 to 0-5 with a single decimal place
  const formatRating = (rating: number) => {
    return (rating / 10).toFixed(1);
  };

  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  if (cuisineLoading) {
    return (
      <div className="min-h-screen flex flex-col">
        <Header 
          mobileMenuOpen={mobileMenuOpen}
          setMobileMenuOpen={setMobileMenuOpen}
        />
        <main className="flex-grow container mx-auto px-6 py-12">
          <Skeleton className="h-10 w-1/3 mb-4" />
          <Skeleton className="h-6 w-2/3 mb-12" />
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {Array(4).fill(0).map((_, index) => (
              <Skeleton key={index} className="h-64 w-full rounded-xl" />
            ))}
          </div>
        </main>
        <Footer />
      </div>
    );
  }

  if (!cuisine) {
    return (
      <div className="min-h-screen flex flex-col">
        <Header 
          mobileMenuOpen={mobileMenuOpen}
          setMobileMenuOpen={setMobileMenuOpen}
        />
        <main className="flex-grow container mx-auto px-6 py-12 text-center">
          <h1 className="font-heading text-3xl font-bold mb-4">Cuisine Not Found</h1>
          <p className="mb-8">The cuisine you're looking for doesn't exist or has been removed.</p>
          <Link href="/" className="bg-primary hover:bg-opacity-90 text-light font-body font-semibold py-3 px-6 rounded-lg text-center transition">
            Return to Home
          </Link>
        </main>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col">
      <Header 
        mobileMenuOpen={mobileMenuOpen}
        setMobileMenuOpen={setMobileMenuOpen}
      />
      <main className="flex-grow">
        <div className="relative h-[40vh] bg-center bg-cover" style={{ backgroundImage: `url('${cuisine.imageUrl}')` }}>
          <div className="absolute inset-0 bg-dark bg-opacity-60"></div>
          <div className="container mx-auto px-6 relative z-10 h-full flex flex-col justify-center">
            <h1 className="font-heading text-4xl md:text-5xl font-bold text-light mb-4">{cuisine.name} Cuisine</h1>
            <p className="font-body text-xl text-light opacity-90 max-w-2xl">{cuisine.description}</p>
          </div>
        </div>
        
        <div className="container mx-auto px-6 py-12">
          <div className="flex items-center justify-between mb-8">
            <h2 className="font-heading text-3xl font-bold">Explore {cuisine.name} Recipes</h2>
            <Link href="/" className="text-primary hover:underline font-semibold flex items-center">
              <i className="ri-arrow-left-line mr-1"></i> Back to Cuisines
            </Link>
          </div>
          
          {recipesLoading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              {Array(4).fill(0).map((_, index) => (
                <div key={index} className="bg-white rounded-xl overflow-hidden shadow-lg flex flex-col md:flex-row">
                  <Skeleton className="h-56 md:h-full md:w-2/5" />
                  <div className="p-6 md:w-3/5">
                    <Skeleton className="h-6 w-3/4 mb-2" />
                    <Skeleton className="h-4 w-1/4 mb-4" />
                    <Skeleton className="h-4 w-full mb-2" />
                    <Skeleton className="h-4 w-full mb-2" />
                    <Skeleton className="h-4 w-3/4 mb-6" />
                    <Skeleton className="h-10 w-1/3" />
                  </div>
                </div>
              ))}
            </div>
          ) : recipes.length === 0 ? (
            <div className="text-center py-12">
              <i className="ri-restaurant-line text-5xl text-gray-300 mb-4"></i>
              <h3 className="font-heading text-2xl font-bold text-gray-600 mb-2">No Recipes Found</h3>
              <p className="text-gray-500 mb-6">We couldn't find any recipes for this cuisine.</p>
              <Link href="/" className="bg-primary hover:bg-opacity-90 text-light font-body font-semibold py-2 px-5 rounded-lg inline-flex items-center transition">
                Explore Other Cuisines
              </Link>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              {recipes.map(recipe => (
                <div key={recipe.id} className="bg-white rounded-xl overflow-hidden shadow-lg hover:shadow-xl transition-shadow flex flex-col md:flex-row">
                  <div className="md:w-2/5 h-56 md:h-auto overflow-hidden">
                    <img 
                      src={recipe.imageUrl} 
                      alt={recipe.name} 
                      className="w-full h-full object-cover transform hover:scale-105 transition-transform duration-500"
                    />
                  </div>
                  <div className="p-6 md:w-3/5">
                    <h3 className="font-heading text-xl font-bold mb-2">{recipe.name}</h3>
                    <div className="flex items-center text-sm mb-3">
                      <span className="flex items-center mr-4">
                        <i className="ri-time-line text-muted mr-1"></i>
                        {recipe.prepTime + recipe.cookTime} mins
                      </span>
                      <span className="flex items-center">
                        <i className="ri-star-fill text-accent mr-1"></i>
                        {formatRating(recipe.rating)}
                      </span>
                    </div>
                    <p className="text-gray-600 mb-5 line-clamp-3">{recipe.description}</p>
                    <Link 
                      href={`/recipe/${recipe.id}`}
                      className="bg-primary hover:bg-opacity-90 text-light font-body font-semibold py-2 px-5 rounded-lg inline-flex items-center transition"
                    >
                      <span>View Recipe</span>
                      <i className="ri-arrow-right-line ml-2"></i>
                    </Link>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </main>
      <Footer />
    </div>
  );
};

export default CuisinePage;