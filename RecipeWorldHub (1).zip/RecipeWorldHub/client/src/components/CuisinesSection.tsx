import { Link } from "wouter";
import { Cuisine } from "@shared/schema";
import { Skeleton } from "@/components/ui/skeleton";

interface CuisinesSectionProps {
  cuisines: Cuisine[];
  isLoading: boolean;
  onCuisineClick: (cuisine: Cuisine) => void;
}

const CuisinesSection = ({ cuisines, isLoading, onCuisineClick }: CuisinesSectionProps) => {
  return (
    <section id="cuisines" className="py-16 px-6">
      <div className="container mx-auto">
        <h2 className="font-heading text-3xl font-bold text-dark text-center mb-3">Explore Cuisines</h2>
        <p className="font-body text-center text-gray-600 max-w-2xl mx-auto mb-12">
          Embark on a global culinary adventure through these diverse cuisines. Click on any cuisine to discover authentic and flavorful recipes.
        </p>
        
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-6 cuisine-grid">
          {isLoading ? (
            // Loading skeletons
            Array(10).fill(0).map((_, index) => (
              <div key={index} className="rounded-xl overflow-hidden shadow-md bg-white">
                <Skeleton className="h-36 w-full" />
                <div className="p-4 text-center">
                  <Skeleton className="h-6 w-20 mx-auto mb-2" />
                  <Skeleton className="h-4 w-16 mx-auto" />
                </div>
              </div>
            ))
          ) : (
            // Actual cuisine cards
            cuisines.map((cuisine) => (
              <div
                key={cuisine.id}
                className="cuisine-card rounded-xl overflow-hidden shadow-md bg-white cursor-pointer"
                onClick={() => onCuisineClick(cuisine)}
              >
                <div className="h-36 overflow-hidden">
                  <img
                    src={cuisine.imageUrl}
                    alt={`${cuisine.name} Cuisine`}
                    className="w-full h-full object-cover"
                  />
                </div>
                <div className="p-4 text-center">
                  <h3 className="font-heading font-bold">{cuisine.name}</h3>
                  <p className="text-sm font-body text-gray-500 mt-1">{cuisine.recipeCount}+ recipes</p>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </section>
  );
};

export default CuisinesSection;
