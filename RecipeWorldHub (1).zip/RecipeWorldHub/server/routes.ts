import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertCuisineSchema, insertRecipeSchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // API routes for cuisines
  app.get("/api/cuisines", async (req, res) => {
    try {
      const cuisines = await storage.getAllCuisines();
      res.json(cuisines);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch cuisines" });
    }
  });
  
  app.get("/api/cuisines/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const cuisine = await storage.getCuisine(id);
      
      if (!cuisine) {
        return res.status(404).json({ message: "Cuisine not found" });
      }
      
      res.json(cuisine);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch cuisine" });
    }
  });
  
  app.post("/api/cuisines", async (req, res) => {
    try {
      const validated = insertCuisineSchema.parse(req.body);
      const cuisine = await storage.createCuisine(validated);
      res.status(201).json(cuisine);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid cuisine data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create cuisine" });
    }
  });
  
  // API routes for recipes
  app.get("/api/recipes", async (req, res) => {
    try {
      const { cuisineId } = req.query;
      
      if (cuisineId) {
        const recipes = await storage.getRecipesByCuisineId(parseInt(cuisineId as string));
        return res.json(recipes);
      }
      
      const recipes = await storage.getAllRecipes();
      res.json(recipes);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch recipes" });
    }
  });
  
  app.get("/api/recipes/featured", async (req, res) => {
    try {
      const recipe = await storage.getFeaturedRecipe();
      
      if (!recipe) {
        return res.status(404).json({ message: "No featured recipe found" });
      }
      
      res.json(recipe);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch featured recipe" });
    }
  });
  
  app.get("/api/recipes/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const recipe = await storage.getRecipe(id);
      
      if (!recipe) {
        return res.status(404).json({ message: "Recipe not found" });
      }
      
      res.json(recipe);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch recipe" });
    }
  });
  
  app.post("/api/recipes", async (req, res) => {
    try {
      const validated = insertRecipeSchema.parse(req.body);
      const recipe = await storage.createRecipe(validated);
      res.status(201).json(recipe);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid recipe data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create recipe" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
