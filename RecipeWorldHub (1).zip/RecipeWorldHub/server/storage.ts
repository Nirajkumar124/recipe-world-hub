import { users, cuisines, recipes, type User, type InsertUser, type Cuisine, type InsertCuisine, type Recipe, type InsertRecipe } from "@shared/schema";

export interface IStorage {
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  getAllCuisines(): Promise<Cuisine[]>;
  getCuisine(id: number): Promise<Cuisine | undefined>;
  createCuisine(cuisine: InsertCuisine): Promise<Cuisine>;
  
  getAllRecipes(): Promise<Recipe[]>;
  getRecipe(id: number): Promise<Recipe | undefined>;
  getRecipesByCuisineId(cuisineId: number): Promise<Recipe[]>;
  getFeaturedRecipe(): Promise<Recipe | undefined>;
  createRecipe(recipe: InsertRecipe): Promise<Recipe>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private cuisinesMap: Map<number, Cuisine>;
  private recipesMap: Map<number, Recipe>;
  private currentUserId: number;
  private currentCuisineId: number;
  private currentRecipeId: number;

  constructor() {
    this.users = new Map();
    this.cuisinesMap = new Map();
    this.recipesMap = new Map();
    this.currentUserId = 1;
    this.currentCuisineId = 1;
    this.currentRecipeId = 1;
    
    // Initialize with sample data
    this.initializeSampleData();
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }
  
  async getAllCuisines(): Promise<Cuisine[]> {
    return Array.from(this.cuisinesMap.values());
  }
  
  async getCuisine(id: number): Promise<Cuisine | undefined> {
    return this.cuisinesMap.get(id);
  }
  
  async createCuisine(insertCuisine: InsertCuisine): Promise<Cuisine> {
    const id = this.currentCuisineId++;
    // Ensure recipeCount has a default value if undefined
    const cuisine: Cuisine = { 
      ...insertCuisine, 
      id,
      recipeCount: insertCuisine.recipeCount ?? 0
    };
    this.cuisinesMap.set(id, cuisine);
    return cuisine;
  }
  
  async getAllRecipes(): Promise<Recipe[]> {
    return Array.from(this.recipesMap.values());
  }
  
  async getRecipe(id: number): Promise<Recipe | undefined> {
    return this.recipesMap.get(id);
  }
  
  async getRecipesByCuisineId(cuisineId: number): Promise<Recipe[]> {
    return Array.from(this.recipesMap.values()).filter(
      (recipe) => recipe.cuisineId === cuisineId
    );
  }
  
  async getFeaturedRecipe(): Promise<Recipe | undefined> {
    return Array.from(this.recipesMap.values()).find(
      (recipe) => recipe.isFeatured
    );
  }
  
  async createRecipe(insertRecipe: InsertRecipe): Promise<Recipe> {
    const id = this.currentRecipeId++;
    
    // Ensure required fields have default values if they're undefined
    const recipe: Recipe = {
      ...insertRecipe,
      id,
      isFeatured: insertRecipe.isFeatured ?? false,
      rating: insertRecipe.rating ?? 0,
      fat: insertRecipe.fat ?? null,
      tips: insertRecipe.tips ?? null,
      calories: insertRecipe.calories ?? null,
      protein: insertRecipe.protein ?? null,
      carbs: insertRecipe.carbs ?? null
    };
    
    this.recipesMap.set(id, recipe);
    
    // Update cuisine recipe count
    const cuisine = this.cuisinesMap.get(recipe.cuisineId);
    if (cuisine) {
      const updatedCuisine = {
        ...cuisine,
        recipeCount: cuisine.recipeCount + 1
      };
      this.cuisinesMap.set(cuisine.id, updatedCuisine);
    }
    
    return recipe;
  }
  
  private initializeSampleData() {
    // Initialize cuisines
    const cuisineData: InsertCuisine[] = [
      {
        name: "Indian",
        description: "Explore the vibrant flavors of India",
        imageUrl: "https://images.unsplash.com/photo-1567337710282-00832b415979?auto=format&fit=crop&q=80&w=1630",
        recipeCount: 4
      },
      {
        name: "Italian",
        description: "Classic dishes from Italy's rich culinary tradition",
        imageUrl: "https://images.unsplash.com/photo-1498579150354-977475b7ea0b?auto=format&fit=crop&q=80&w=1770",
        recipeCount: 3
      },
      {
        name: "Chinese",
        description: "Traditional and modern Chinese recipes",
        imageUrl: "https://images.unsplash.com/photo-1563245372-f21724e3856d?auto=format&fit=crop&q=80&w=1769",
        recipeCount: 3
      },
      {
        name: "Mexican",
        description: "Bold and flavorful Mexican cuisine",
        imageUrl: "https://images.unsplash.com/photo-1565299585323-38d6b0865b47?auto=format&fit=crop&q=80&w=1780",
        recipeCount: 2
      },
      {
        name: "Japanese",
        description: "Elegant and refined Japanese dishes",
        imageUrl: "https://images.unsplash.com/photo-1579584425555-c3ce17fd4351?auto=format&fit=crop&q=80&w=1784",
        recipeCount: 2
      },
      {
        name: "Thai",
        description: "Aromatic and spicy Thai cuisine",
        imageUrl: "https://images.unsplash.com/photo-1607330289024-1535c6b4e1c1?auto=format&fit=crop&q=80&w=1674",
        recipeCount: 2
      },
      {
        name: "French",
        description: "Sophisticated French culinary classics",
        imageUrl: "https://images.unsplash.com/photo-1614707267537-b85aaf00c4b7?auto=format&fit=crop&q=80&w=1587",
        recipeCount: 2
      },
      {
        name: "Mediterranean",
        description: "Healthy and flavorful Mediterranean dishes",
        imageUrl: "https://images.unsplash.com/photo-1599041127805-7c6ade9c8392?auto=format&fit=crop&q=80&w=1770",
        recipeCount: 2
      },
      {
        name: "Korean",
        description: "Bold and savory Korean specialties",
        imageUrl: "https://images.unsplash.com/photo-1532347231146-80afc9e3df2b?auto=format&fit=crop&q=80&w=1769",
        recipeCount: 2
      },
      {
        name: "Middle Eastern",
        description: "Rich and aromatic Middle Eastern cuisine",
        imageUrl: "https://images.unsplash.com/photo-1606666308225-4114a3e41e8d?auto=format&fit=crop&q=80&w=1770",
        recipeCount: 2
      }
    ];
    
    cuisineData.forEach(cuisine => {
      const id = this.currentCuisineId++;
      this.cuisinesMap.set(id, { 
        ...cuisine, 
        id,
        recipeCount: cuisine.recipeCount ?? 0 
      });
    });
    
    // Initialize recipes
    const recipeData: InsertRecipe[] = [
      // Indian Cuisine (ID: 1)
      {
        cuisineId: 1,
        name: "Butter Chicken",
        description: "Rich and creamy tomato-based curry with tender chicken pieces.",
        imageUrl: "https://images.unsplash.com/photo-1603894584373-5ac82b2ae398?auto=format&fit=crop&q=80&w=1770",
        prepTime: 15,
        cookTime: 30,
        servings: 4,
        difficulty: "Medium",
        isFeatured: true,
        rating: 48,
        ingredients: [
          "500g boneless chicken, cut into pieces",
          "2 tablespoons butter",
          "1 large onion, finely chopped",
          "2 tablespoons ginger-garlic paste",
          "2 cups tomato puree",
          "1 tablespoon garam masala",
          "1 teaspoon red chili powder",
          "1/2 cup heavy cream",
          "Salt to taste",
          "Fresh coriander for garnish"
        ],
        steps: [
          "Marinate chicken with yogurt, ginger-garlic paste, and spices for at least 1 hour.",
          "Heat butter in a large pan. Add onions and sauté until golden brown.",
          "Add ginger-garlic paste and cook for 1-2 minutes until fragrant.",
          "Add tomato puree and cook for 5-7 minutes until oil separates.",
          "Add spices and salt. Mix well and cook for 2 minutes.",
          "Add marinated chicken and cook until it's no longer pink, about 8-10 minutes.",
          "Pour in heavy cream, mix well, and simmer for 5 minutes until the sauce thickens.",
          "Garnish with fresh coriander and serve hot with naan or rice."
        ],
        tips: [
          "For a smokier flavor, add 1 teaspoon of kasoori methi (dried fenugreek leaves).",
          "To make it less spicy, reduce the amount of red chili powder and add more cream.",
          "Marinating the chicken overnight will enhance the flavors significantly."
        ],
        calories: 420,
        protein: 28,
        carbs: 12,
        fat: 32
      },
      {
        cuisineId: 1,
        name: "Palak Paneer",
        description: "Creamy spinach curry with soft paneer cheese cubes.",
        imageUrl: "https://images.unsplash.com/photo-1601576086486-15fed48d2e56?auto=format&fit=crop&q=80&w=1770",
        prepTime: 15,
        cookTime: 20,
        servings: 4,
        difficulty: "Easy",
        isFeatured: false,
        rating: 46,
        ingredients: [
          "250g paneer, cubed",
          "500g spinach, blanched and pureed",
          "1 onion, finely chopped",
          "2 tomatoes, pureed",
          "1 tsp cumin seeds",
          "1 tsp ginger-garlic paste",
          "1/2 tsp garam masala",
          "1/2 tsp turmeric",
          "1/4 cup cream",
          "Salt to taste"
        ],
        steps: [
          "Blanch spinach in hot water for 2-3 minutes, then blend into a smooth puree.",
          "Heat oil in a pan, add cumin seeds and let them splutter.",
          "Add chopped onions and sauté until golden brown.",
          "Add ginger-garlic paste and cook for 1 minute.",
          "Add tomato puree and cook until oil separates.",
          "Add spices and salt, mix well.",
          "Add spinach puree and cook for 5 minutes.",
          "Add paneer cubes and cream, simmer for 2-3 minutes.",
          "Serve hot with roti or rice."
        ],
        tips: [
          "For softer paneer, soak the cubes in warm water for 10 minutes before using.",
          "Add a little water if the curry is too thick.",
          "You can fry the paneer lightly before adding to the spinach for extra flavor."
        ],
        calories: 320,
        protein: 18,
        carbs: 10,
        fat: 24
      },
      // Italian Cuisine (ID: 2)
      {
        cuisineId: 2,
        name: "Authentic Margherita Pizza",
        description: "Classic Italian pizza with fresh tomatoes, mozzarella, and basil.",
        imageUrl: "https://images.unsplash.com/photo-1627626775846-122b778965ae?auto=format&fit=crop&q=80&w=1974",
        prepTime: 20,
        cookTime: 15,
        servings: 2,
        difficulty: "Medium",
        isFeatured: false,
        rating: 47,
        ingredients: [
          "300g pizza dough",
          "100g fresh mozzarella, sliced",
          "2 ripe tomatoes, sliced",
          "Fresh basil leaves",
          "2 tbsp olive oil",
          "1 clove garlic, minced",
          "Salt and pepper to taste"
        ],
        steps: [
          "Preheat oven to 475°F (245°C) with pizza stone if available.",
          "Roll out pizza dough on floured surface to desired thickness.",
          "Mix olive oil with minced garlic and brush over dough.",
          "Arrange tomato slices and mozzarella on top.",
          "Season with salt and pepper.",
          "Bake for 12-15 minutes until crust is golden and cheese is bubbly.",
          "Remove from oven and top with fresh basil leaves.",
          "Drizzle with a little extra olive oil before serving."
        ],
        tips: [
          "Use room temperature dough for easier stretching.",
          "Pat dry the mozzarella slices to prevent soggy pizza.",
          "For authentic flavor, use San Marzano tomatoes if available."
        ],
        calories: 340,
        protein: 14,
        carbs: 42,
        fat: 14
      },
      {
        cuisineId: 2,
        name: "Homemade Fettuccine Alfredo",
        description: "Creamy pasta dish with homemade Alfredo sauce, perfect for a comforting dinner.",
        imageUrl: "https://images.unsplash.com/photo-1645112411341-6c4fd023882c?auto=format&fit=crop&q=80&w=1770",
        prepTime: 10,
        cookTime: 15,
        servings: 4,
        difficulty: "Easy",
        isFeatured: false,
        rating: 45,
        ingredients: [
          "400g fettuccine pasta",
          "100g butter",
          "200ml heavy cream",
          "1 cup grated Parmesan cheese",
          "2 cloves garlic, minced",
          "Salt and pepper to taste",
          "Fresh parsley for garnish"
        ],
        steps: [
          "Cook fettuccine in salted water according to package instructions.",
          "In a large pan, melt butter over medium heat.",
          "Add minced garlic and sauté for 1 minute until fragrant.",
          "Pour in heavy cream and bring to a gentle simmer.",
          "Add grated Parmesan cheese and stir until melted and sauce is smooth.",
          "Season with salt and pepper to taste.",
          "Drain pasta and add to the sauce, tossing to coat thoroughly.",
          "Garnish with additional Parmesan and chopped parsley before serving."
        ],
        tips: [
          "Reserve some pasta water to thin the sauce if needed.",
          "Use freshly grated Parmesan for the smoothest sauce.",
          "If sauce becomes too thick, add a splash of cream or pasta water."
        ],
        calories: 520,
        protein: 18,
        carbs: 48,
        fat: 30
      },
      // Chinese Cuisine (ID: 3)
      {
        cuisineId: 3,
        name: "Kung Pao Chicken",
        description: "Spicy stir-fried Chinese chicken dish with peanuts, vegetables, and chili peppers.",
        imageUrl: "https://images.unsplash.com/photo-1525755662778-989d0524087e?auto=format&fit=crop&q=80&w=1974",
        prepTime: 15,
        cookTime: 10,
        servings: 4,
        difficulty: "Medium",
        isFeatured: false,
        rating: 46,
        ingredients: [
          "500g chicken breast, cubed",
          "1 cup peanuts, roasted",
          "2 red bell peppers, diced",
          "1 zucchini, diced",
          "5 dried red chilies",
          "3 cloves garlic, minced",
          "1 inch ginger, minced",
          "3 tbsp soy sauce",
          "1 tbsp rice vinegar",
          "1 tbsp hoisin sauce",
          "1 tsp cornstarch",
          "2 tbsp vegetable oil",
          "2 green onions, sliced"
        ],
        steps: [
          "Mix chicken with 1 tbsp soy sauce and cornstarch. Let marinate for 10 minutes.",
          "Combine remaining soy sauce, rice vinegar, and hoisin sauce in a bowl.",
          "Heat oil in a wok over high heat.",
          "Add dried chilies, garlic, and ginger. Stir-fry for 30 seconds until fragrant.",
          "Add chicken and stir-fry for 3-4 minutes until nearly cooked through.",
          "Add bell peppers and zucchini, stir-fry for 2 minutes.",
          "Pour in sauce mixture and stir well.",
          "Add peanuts and cook for 1 more minute until sauce thickens.",
          "Garnish with green onions and serve with rice."
        ],
        tips: [
          "Toast the peanuts lightly for enhanced flavor.",
          "Adjust chili quantity based on your spice preference.",
          "Serve immediately after cooking for the best texture and flavor."
        ],
        calories: 380,
        protein: 30,
        carbs: 15,
        fat: 23
      },
      {
        cuisineId: 3,
        name: "Vegetable Spring Rolls",
        description: "Crispy fried spring rolls filled with fresh vegetables and served with sweet chili sauce.",
        imageUrl: "https://images.unsplash.com/photo-1606720402689-5682da1c7f95?auto=format&fit=crop&q=80&w=1965",
        prepTime: 30,
        cookTime: 15,
        servings: 4,
        difficulty: "Medium",
        isFeatured: false,
        rating: 44,
        ingredients: [
          "20 spring roll wrappers",
          "2 cups cabbage, finely shredded",
          "1 carrot, julienned",
          "1 cup bean sprouts",
          "3 green onions, chopped",
          "2 cloves garlic, minced",
          "1 tbsp soy sauce",
          "1 tsp sesame oil",
          "1 tsp ginger, grated",
          "Vegetable oil for frying",
          "Sweet chili sauce for dipping"
        ],
        steps: [
          "Heat a little oil in a pan and sauté garlic and ginger until fragrant.",
          "Add cabbage, carrot, and bean sprouts. Stir-fry for 3-4 minutes until softened.",
          "Add soy sauce, sesame oil, and green onions. Mix well and remove from heat.",
          "Allow the filling to cool completely.",
          "Place a spoonful of filling on each spring roll wrapper, fold in sides, and roll tightly.",
          "Seal the edges with a little water.",
          "Heat oil in a deep pan to 350°F (175°C).",
          "Fry spring rolls in batches until golden brown and crispy, about 3-4 minutes.",
          "Drain on paper towels and serve hot with sweet chili sauce."
        ],
        tips: [
          "Ensure filling is completely cooled before wrapping to prevent soggy rolls.",
          "Keep spring roll wrappers covered with a damp cloth to prevent drying out.",
          "For a healthier version, these can be baked at 400°F (200°C) for 15-20 minutes."
        ],
        calories: 220,
        protein: 5,
        carbs: 28,
        fat: 12
      },
      // Mexican Cuisine (ID: 4)
      {
        cuisineId: 4,
        name: "Authentic Beef Tacos",
        description: "Traditional Mexican tacos with seasoned ground beef, fresh toppings, and warm corn tortillas.",
        imageUrl: "https://images.unsplash.com/photo-1551504734-5ee1c4a3479c?auto=format&fit=crop&q=80&w=1770",
        prepTime: 15,
        cookTime: 20,
        servings: 4,
        difficulty: "Easy",
        isFeatured: false,
        rating: 47,
        ingredients: [
          "500g ground beef",
          "12 corn tortillas",
          "1 onion, diced",
          "3 cloves garlic, minced",
          "2 tbsp taco seasoning",
          "1 cup lettuce, shredded",
          "1 cup tomatoes, diced",
          "1/2 cup cheddar cheese, grated",
          "1/4 cup cilantro, chopped",
          "1 lime, cut into wedges",
          "Sour cream and salsa for serving"
        ],
        steps: [
          "Heat a large skillet over medium-high heat.",
          "Add ground beef and cook until browned, breaking it up as it cooks.",
          "Add diced onion and garlic, cook for 2-3 minutes until softened.",
          "Sprinkle taco seasoning over the beef and stir well.",
          "Add 1/4 cup water, bring to a simmer, and cook for 5 minutes until liquid is reduced.",
          "Meanwhile, warm the tortillas in a dry pan or microwave.",
          "Assemble tacos with beef mixture, lettuce, tomatoes, cheese, and cilantro.",
          "Serve with lime wedges, sour cream, and salsa on the side."
        ],
        tips: [
          "Toast the tortillas slightly for better texture and flavor.",
          "For authentic flavor, make your own taco seasoning with cumin, chili powder, paprika, and oregano.",
          "Set up a taco bar so everyone can build their own tacos."
        ],
        calories: 380,
        protein: 24,
        carbs: 30,
        fat: 18
      },
      {
        cuisineId: 4,
        name: "Guacamole",
        description: "Classic Mexican avocado dip with lime, cilantro, and a hint of spice.",
        imageUrl: "https://images.unsplash.com/photo-1600335895229-6e75511892c8?auto=format&fit=crop&q=80&w=1887",
        prepTime: 15,
        cookTime: 0,
        servings: 4,
        difficulty: "Easy",
        isFeatured: false,
        rating: 45,
        ingredients: [
          "3 ripe avocados",
          "1 lime, juiced",
          "1 small red onion, finely diced",
          "1 tomato, seeds removed and diced",
          "1 jalapeño, seeds removed and minced",
          "2 tbsp cilantro, chopped",
          "1 clove garlic, minced",
          "Salt and pepper to taste",
          "Tortilla chips for serving"
        ],
        steps: [
          "Cut avocados in half, remove pits, and scoop flesh into a bowl.",
          "Mash avocados with a fork to desired consistency (chunky or smooth).",
          "Add lime juice and mix to prevent browning.",
          "Fold in diced onion, tomato, jalapeño, cilantro, and garlic.",
          "Season with salt and pepper to taste.",
          "Serve immediately with tortilla chips or refrigerate with plastic wrap touching the surface to prevent browning."
        ],
        tips: [
          "For best flavor, make guacamole no more than 1-2 hours before serving.",
          "Keep the avocado pit in the guacamole to help prevent browning.",
          "Adjust jalapeño amount to control spiciness."
        ],
        calories: 150,
        protein: 2,
        carbs: 9,
        fat: 13
      },
      // Japanese Cuisine (ID: 5)
      {
        cuisineId: 5,
        name: "Salmon Sushi Rolls",
        description: "Fresh and delicious homemade sushi rolls with salmon, avocado, and cucumber.",
        imageUrl: "https://images.unsplash.com/photo-1579584425555-c3ce17fd4351?auto=format&fit=crop&q=80&w=1784",
        prepTime: 30,
        cookTime: 20,
        servings: 4,
        difficulty: "Medium",
        isFeatured: false,
        rating: 46,
        ingredients: [
          "2 cups sushi rice",
          "3 cups water",
          "1/4 cup rice vinegar",
          "2 tbsp sugar",
          "1 tsp salt",
          "200g fresh sashimi-grade salmon",
          "1 avocado, sliced",
          "1 cucumber, julienned",
          "5 nori sheets",
          "Wasabi, pickled ginger, and soy sauce for serving"
        ],
        steps: [
          "Rinse sushi rice until water runs clear, then cook with water according to package instructions.",
          "Mix rice vinegar, sugar, and salt in a small saucepan and heat until dissolved.",
          "Transfer cooked rice to a wooden bowl and pour vinegar mixture over it. Fold gently to combine.",
          "Let rice cool to room temperature.",
          "Place a nori sheet on a bamboo sushi mat, shiny side down.",
          "Spread a thin layer of rice over the nori, leaving 1 inch at the top edge bare.",
          "Arrange salmon, avocado, and cucumber in a line across the center.",
          "Roll the sushi mat tightly, pressing gently to shape.",
          "Use a sharp knife dipped in water to slice rolls into 6-8 pieces each.",
          "Serve with wasabi, pickled ginger, and soy sauce."
        ],
        tips: [
          "Use a very sharp knife and wipe it clean between cuts for neat slices.",
          "Moisten your hands with water to prevent rice from sticking while handling.",
          "For best results, use fresh sashimi-grade salmon from a reputable source."
        ],
        calories: 280,
        protein: 12,
        carbs: 42,
        fat: 8
      },
      {
        cuisineId: 5,
        name: "Chicken Teriyaki",
        description: "Juicy chicken glazed with sweet and savory teriyaki sauce.",
        imageUrl: "https://images.unsplash.com/photo-1546069901-d5bfd2cbfb1f?auto=format&fit=crop&q=80&w=1780",
        prepTime: 10,
        cookTime: 15,
        servings: 4,
        difficulty: "Easy",
        isFeatured: false,
        rating: 45,
        ingredients: [
          "4 boneless, skinless chicken thighs",
          "1/4 cup soy sauce",
          "1/4 cup mirin",
          "2 tbsp sake (or white wine)",
          "2 tbsp sugar",
          "1 tbsp honey",
          "1 inch ginger, grated",
          "2 cloves garlic, minced",
          "1 tbsp vegetable oil",
          "Sesame seeds and sliced green onions for garnish",
          "Steamed rice for serving"
        ],
        steps: [
          "In a bowl, mix soy sauce, mirin, sake, sugar, honey, ginger, and garlic to make teriyaki sauce.",
          "Heat oil in a large skillet over medium-high heat.",
          "Add chicken thighs and cook for 5-6 minutes on each side until golden brown.",
          "Pour in teriyaki sauce and bring to a simmer.",
          "Reduce heat to medium-low and continue cooking, occasionally spooning sauce over chicken, for 5-7 minutes until sauce thickens and chicken is glazed.",
          "Remove chicken and slice into strips.",
          "Drizzle with remaining sauce and garnish with sesame seeds and green onions.",
          "Serve with steamed rice."
        ],
        tips: [
          "Allow sauce to reduce until it's syrupy for the perfect glaze.",
          "For extra flavor, marinate chicken in some of the teriyaki sauce for 1-2 hours before cooking.",
          "Chicken breasts can be substituted, but reduce cooking time to prevent drying out."
        ],
        calories: 320,
        protein: 24,
        carbs: 18,
        fat: 16
      },
      // Thai Cuisine (ID: 6)
      {
        cuisineId: 6,
        name: "Spicy Thai Basil Stir Fry",
        description: "A fragrant and spicy Thai stir fry with aromatic basil leaves, tender chicken, and colorful vegetables.",
        imageUrl: "https://images.unsplash.com/photo-1455619452474-d2be8b1e70cd?auto=format&fit=crop&q=80&w=1770",
        prepTime: 10,
        cookTime: 20,
        servings: 4,
        difficulty: "Medium",
        isFeatured: false,
        rating: 47,
        ingredients: [
          "400g chicken breast, thinly sliced",
          "4 cloves garlic, minced",
          "3 Thai chilies, chopped",
          "1 red bell pepper, sliced",
          "1 onion, sliced",
          "2 cups Thai basil leaves",
          "2 tbsp vegetable oil",
          "2 tbsp oyster sauce",
          "1 tbsp fish sauce",
          "1 tbsp soy sauce",
          "1 tsp sugar"
        ],
        steps: [
          "Heat oil in a wok over high heat.",
          "Add garlic and chilies, stir fry for 30 seconds until fragrant.",
          "Add chicken and stir fry until no longer pink, about 3-4 minutes.",
          "Add bell pepper and onion, stir fry for 2 minutes until slightly softened.",
          "Mix in the sauces and sugar, stir well.",
          "Turn off heat and add basil leaves, stirring until wilted.",
          "Serve hot with steamed rice."
        ],
        tips: [
          "Use Thai holy basil for authentic flavor if available.",
          "Adjust the number of chilies based on your spice preference.",
          "You can substitute chicken with beef, pork, tofu, or seafood."
        ],
        calories: 310,
        protein: 24,
        carbs: 12,
        fat: 18
      },
      {
        cuisineId: 6,
        name: "Tom Yum Soup",
        description: "Hot and sour Thai soup with shrimp, mushrooms, and aromatic herbs.",
        imageUrl: "https://images.unsplash.com/photo-1548943487-a2e4e43b4853?auto=format&fit=crop&q=80&w=1770",
        prepTime: 15,
        cookTime: 20,
        servings: 4,
        difficulty: "Medium",
        isFeatured: false,
        rating: 46,
        ingredients: [
          "400g shrimp, peeled and deveined",
          "4 cups chicken broth",
          "2 stalks lemongrass, bruised and cut into 2-inch pieces",
          "4 kaffir lime leaves",
          "1 inch galangal or ginger, sliced",
          "2 Thai chili peppers, sliced",
          "200g mushrooms, sliced",
          "2 tomatoes, quartered",
          "1 onion, sliced",
          "3 tbsp fish sauce",
          "2 tbsp lime juice",
          "1 tbsp sugar",
          "Fresh cilantro for garnish"
        ],
        steps: [
          "In a large pot, bring chicken broth to a boil.",
          "Add lemongrass, lime leaves, galangal, and chili peppers. Simmer for 5 minutes to infuse flavors.",
          "Add mushrooms, tomatoes, and onion. Simmer for 5 more minutes.",
          "Add shrimp and cook for 2-3 minutes until they turn pink.",
          "Stir in fish sauce, lime juice, and sugar. Adjust seasoning to taste.",
          "Remove from heat and garnish with fresh cilantro before serving."
        ],
        tips: [
          "For a creamier version (Tom Kha), add 1 cup of coconut milk.",
          "The herbs (lemongrass, lime leaves, galangal) are for flavor only and not typically eaten.",
          "Adjust the amount of chili based on your spice preference."
        ],
        calories: 220,
        protein: 24,
        carbs: 9,
        fat: 8
      },
      // Add sample recipes for the remaining cuisines
      // French Cuisine (ID: 7)
      {
        cuisineId: 7,
        name: "Coq au Vin",
        description: "Classic French chicken braised with wine, mushrooms, and bacon.",
        imageUrl: "https://images.unsplash.com/photo-1600335895229-6e75511892c8?auto=format&fit=crop&q=80&w=1887",
        prepTime: 30,
        cookTime: 90,
        servings: 6,
        difficulty: "Medium",
        isFeatured: false,
        rating: 48,
        ingredients: [
          "1 whole chicken, cut into 8 pieces",
          "200g bacon, diced",
          "2 cups red wine (preferably Burgundy)",
          "2 cups chicken stock",
          "1 large onion, diced",
          "2 carrots, sliced",
          "300g mushrooms, quartered",
          "3 cloves garlic, minced",
          "2 tbsp tomato paste",
          "1 bouquet garni (thyme, bay leaf, parsley)",
          "3 tbsp butter",
          "2 tbsp flour",
          "Fresh parsley for garnish"
        ],
        steps: [
          "Season chicken pieces with salt and pepper.",
          "In a large Dutch oven, cook bacon until crispy. Remove and set aside.",
          "Brown chicken pieces in bacon fat, then set aside.",
          "In the same pot, sauté onions, carrots, and garlic until softened.",
          "Add tomato paste and cook for 1 minute.",
          "Return chicken and bacon to the pot. Add wine, stock, and bouquet garni.",
          "Bring to a simmer, cover, and cook for 1 hour until chicken is tender.",
          "In a separate pan, sauté mushrooms in butter until golden.",
          "Mix flour with softened butter to create a paste.",
          "Stir mushrooms and flour paste into the chicken mixture and simmer for 10-15 minutes until sauce thickens.",
          "Garnish with fresh parsley before serving."
        ],
        tips: [
          "Marinate the chicken in wine overnight for enhanced flavor.",
          "Use a good quality wine that you would enjoy drinking.",
          "Serve with mashed potatoes or crusty bread to soak up the delicious sauce."
        ],
        calories: 450,
        protein: 35,
        carbs: 8,
        fat: 28
      },
      {
        cuisineId: 7,
        name: "Crème Brûlée",
        description: "Elegant French dessert with rich custard and caramelized sugar top.",
        imageUrl: "https://images.unsplash.com/photo-1488477181946-6428a0291777?auto=format&fit=crop&q=80&w=1887",
        prepTime: 20,
        cookTime: 40,
        servings: 6,
        difficulty: "Medium",
        isFeatured: false,
        rating: 47,
        ingredients: [
          "6 egg yolks",
          "600ml heavy cream",
          "100g granulated sugar, plus extra for topping",
          "1 vanilla bean, split and scraped",
          "Pinch of salt"
        ],
        steps: [
          "Preheat oven to 325°F (165°C).",
          "In a saucepan, heat cream with vanilla bean seeds and pod until it just begins to simmer.",
          "In a bowl, whisk egg yolks with sugar and salt until pale.",
          "Slowly whisk hot cream into egg mixture.",
          "Strain mixture through a fine sieve.",
          "Pour into 6 ramekins and place them in a deep baking dish.",
          "Fill baking dish with hot water halfway up the sides of the ramekins.",
          "Bake for 35-40 minutes until custards are set but still slightly jiggly in the center.",
          "Cool completely, then refrigerate for at least 4 hours or overnight.",
          "Before serving, sprinkle sugar evenly over each custard.",
          "Use a kitchen torch to caramelize the sugar until golden brown and crisp."
        ],
        tips: [
          "For the perfect crack, ensure the custard is well-chilled before caramelizing the top.",
          "If you don't have a kitchen torch, place under a preheated broiler for 2-3 minutes.",
          "Vanilla extract can be substituted for vanilla bean if necessary."
        ],
        calories: 380,
        protein: 5,
        carbs: 22,
        fat: 32
      },
      // Mediterranean Cuisine (ID: 8)
      {
        cuisineId: 8,
        name: "Greek Moussaka",
        description: "Traditional layered casserole with eggplant, potatoes, and spiced meat topped with béchamel sauce.",
        imageUrl: "https://images.unsplash.com/photo-1551504734-5ee1c4a3479c?auto=format&fit=crop&q=80&w=1770",
        prepTime: 45,
        cookTime: 60,
        servings: 8,
        difficulty: "Hard",
        isFeatured: false,
        rating: 47,
        ingredients: [
          "2 large eggplants, sliced",
          "3 potatoes, sliced",
          "500g ground lamb or beef",
          "1 onion, chopped",
          "3 cloves garlic, minced",
          "1 can (400g) tomatoes, chopped",
          "2 tbsp tomato paste",
          "1 tsp cinnamon",
          "1/2 tsp allspice",
          "1/4 cup red wine",
          "2 tbsp olive oil",
          "Salt and pepper to taste",
          "For béchamel sauce:",
          "50g butter",
          "50g flour",
          "500ml milk",
          "2 eggs, beaten",
          "1/2 cup grated Parmesan cheese",
          "Pinch of nutmeg"
        ],
        steps: [
          "Preheat oven to 375°F (190°C).",
          "Salt eggplant slices and let sit for 30 minutes. Rinse and pat dry.",
          "Brush eggplant and potato slices with olive oil and bake for 20 minutes until soft.",
          "In a large pan, cook onion and garlic until soft. Add meat and brown thoroughly.",
          "Add tomatoes, tomato paste, cinnamon, allspice, wine, salt, and pepper. Simmer for 20 minutes.",
          "For béchamel, melt butter in a saucepan and stir in flour to make a roux.",
          "Gradually add milk, stirring constantly until sauce thickens.",
          "Remove from heat and slowly whisk in eggs, Parmesan, and nutmeg.",
          "In a baking dish, layer potatoes, half the eggplant, meat sauce, remaining eggplant.",
          "Pour béchamel sauce over the top and smooth with a spatula.",
          "Bake for 45-60 minutes until golden brown and bubbling.",
          "Let rest for 15 minutes before serving."
        ],
        tips: [
          "Salting the eggplant helps remove bitterness and excess moisture.",
          "Let the moussaka rest before serving to allow it to set properly.",
          "For a vegetarian version, substitute the meat with lentils or a meat substitute."
        ],
        calories: 420,
        protein: 24,
        carbs: 28,
        fat: 25
      },
      {
        cuisineId: 8,
        name: "Mediterranean Quinoa Salad",
        description: "Refreshing and nutritious salad with quinoa, fresh vegetables, olives, and feta cheese.",
        imageUrl: "https://images.unsplash.com/photo-1512621776951-a57141f2eefd?auto=format&fit=crop&q=80&w=1770",
        prepTime: 15,
        cookTime: 15,
        servings: 4,
        difficulty: "Easy",
        isFeatured: false,
        rating: 44,
        ingredients: [
          "1 cup quinoa, rinsed",
          "2 cups water or vegetable broth",
          "1 cucumber, diced",
          "2 tomatoes, diced",
          "1 red bell pepper, diced",
          "1/2 red onion, finely chopped",
          "1/2 cup Kalamata olives, pitted and halved",
          "1/2 cup feta cheese, crumbled",
          "1/4 cup fresh parsley, chopped",
          "1/4 cup fresh mint, chopped",
          "3 tbsp olive oil",
          "2 tbsp lemon juice",
          "1 clove garlic, minced",
          "1 tsp dried oregano",
          "Salt and pepper to taste"
        ],
        steps: [
          "Cook quinoa in water or broth according to package instructions. Let cool completely.",
          "In a large bowl, combine cooled quinoa, cucumber, tomatoes, bell pepper, red onion, olives, and herbs.",
          "In a small bowl, whisk together olive oil, lemon juice, garlic, oregano, salt, and pepper.",
          "Pour dressing over the salad and toss gently to combine.",
          "Sprinkle crumbled feta over the top and toss lightly.",
          "Refrigerate for at least 30 minutes before serving to allow flavors to meld."
        ],
        tips: [
          "Rinse quinoa thoroughly before cooking to remove its bitter coating.",
          "This salad keeps well in the refrigerator for up to 3 days.",
          "Add grilled chicken or chickpeas for extra protein."
        ],
        calories: 280,
        protein: 9,
        carbs: 32,
        fat: 15
      },
      // Korean Cuisine (ID: 9)
      {
        cuisineId: 9,
        name: "Bibimbap",
        description: "Colorful Korean rice bowl topped with vegetables, meat, egg, and spicy gochujang sauce.",
        imageUrl: "https://images.unsplash.com/photo-1553163147-622ab57be1c7?auto=format&fit=crop&q=80&w=1770",
        prepTime: 30,
        cookTime: 20,
        servings: 4,
        difficulty: "Medium",
        isFeatured: false,
        rating: 46,
        ingredients: [
          "2 cups short-grain rice, cooked",
          "200g beef sirloin, thinly sliced",
          "2 tbsp soy sauce",
          "1 tbsp sesame oil",
          "1 tbsp sugar",
          "2 cloves garlic, minced",
          "1 carrot, julienned",
          "1 zucchini, julienned",
          "200g spinach",
          "100g bean sprouts",
          "4 eggs",
          "4 tbsp gochujang (Korean chili paste)",
          "2 tbsp vegetable oil",
          "Sesame seeds for garnish"
        ],
        steps: [
          "Marinate beef in soy sauce, 1 tsp sesame oil, sugar, and garlic for 30 minutes.",
          "Sauté each vegetable separately with a pinch of salt until just tender, set aside.",
          "Cook marinated beef in a hot pan until browned, about 3-4 minutes.",
          "Fry eggs sunny-side up in a separate pan.",
          "In serving bowls, place a portion of rice at the bottom.",
          "Arrange vegetables and beef in separate sections around the rice.",
          "Place a fried egg on top of each bowl.",
          "Mix gochujang with remaining sesame oil and serve on the side.",
          "To eat, mix everything together with the gochujang sauce."
        ],
        tips: [
          "Traditional bibimbap is served in a hot stone bowl (dolsot bibimbap) which creates crispy rice.",
          "Customize with your favorite vegetables - mushrooms, kimchi, and cucumber are great additions.",
          "Adjust the amount of gochujang based on your spice preference."
        ],
        calories: 480,
        protein: 24,
        carbs: 60,
        fat: 16
      },
      {
        cuisineId: 9,
        name: "Kimchi Jjigae",
        description: "Spicy and tangy Korean stew made with kimchi, pork, and tofu.",
        imageUrl: "https://images.unsplash.com/photo-1498579150354-977475b7ea0b?auto=format&fit=crop&q=80&w=1770",
        prepTime: 15,
        cookTime: 30,
        servings: 4,
        difficulty: "Medium",
        isFeatured: false,
        rating: 45,
        ingredients: [
          "2 cups kimchi, chopped",
          "1/2 cup kimchi juice",
          "200g pork belly, sliced",
          "1 block tofu, cubed",
          "1 onion, sliced",
          "2 green onions, chopped",
          "2 cloves garlic, minced",
          "1 tbsp gochugaru (Korean red pepper flakes)",
          "1 tbsp gochujang (Korean chili paste)",
          "1 tsp sugar",
          "1 tbsp soy sauce",
          "3 cups water or anchovy stock",
          "1 tsp sesame oil"
        ],
        steps: [
          "In a pot, cook pork belly over medium heat until fat renders, about 4-5 minutes.",
          "Add kimchi and onion, sauté for 5 minutes until kimchi softens.",
          "Add garlic, gochugaru, gochujang, sugar, and soy sauce. Mix well.",
          "Pour in water or stock and kimchi juice. Bring to a boil.",
          "Reduce heat and simmer for 15 minutes to develop flavors.",
          "Add tofu cubes and simmer for another 5 minutes.",
          "Stir in sesame oil and green onions just before serving.",
          "Serve hot with a side of rice."
        ],
        tips: [
          "Use older, more fermented kimchi for the best flavor.",
          "For a seafood version, substitute pork with sliced fish or clams.",
          "For extra richness, crack a raw egg into the hot stew just before serving."
        ],
        calories: 360,
        protein: 20,
        carbs: 14,
        fat: 26
      },
      // Middle Eastern Cuisine (ID: 10)
      {
        cuisineId: 10,
        name: "Lamb Kofta Kebabs",
        description: "Juicy Middle Eastern spiced ground lamb skewers, grilled to perfection.",
        imageUrl: "https://images.unsplash.com/photo-1532636875304-0c89119d9b4d?auto=format&fit=crop&q=80&w=1770",
        prepTime: 20,
        cookTime: 10,
        servings: 4,
        difficulty: "Medium",
        isFeatured: false,
        rating: 47,
        ingredients: [
          "500g ground lamb",
          "1 onion, finely grated",
          "3 cloves garlic, minced",
          "1/4 cup fresh parsley, chopped",
          "1/4 cup fresh mint, chopped",
          "1 tsp ground cumin",
          "1 tsp ground coriander",
          "1/2 tsp cinnamon",
          "1/2 tsp allspice",
          "1/4 tsp cayenne pepper",
          "1 tsp salt",
          "1/2 tsp black pepper",
          "1 tbsp olive oil",
          "Wooden skewers, soaked in water"
        ],
        steps: [
          "In a large bowl, combine all ingredients except olive oil and mix thoroughly by hand.",
          "Cover and refrigerate for at least 1 hour to allow flavors to meld.",
          "Divide mixture into 8 portions and shape each around a skewer into an oblong kofta shape.",
          "Brush with olive oil on all sides.",
          "Preheat grill or grill pan to medium-high heat.",
          "Grill kebabs for 3-4 minutes per side until browned and cooked through.",
          "Serve with warm pita bread, tzatziki sauce, and fresh vegetables."
        ],
        tips: [
          "For juicier kofta, use lamb with 15-20% fat content.",
          "Don't overwork the meat mixture to avoid tough kebabs.",
          "If using bamboo skewers, soak them in water for 30 minutes to prevent burning."
        ],
        calories: 320,
        protein: 24,
        carbs: 4,
        fat: 24
      },
      {
        cuisineId: 10,
        name: "Hummus with Pita",
        description: "Creamy chickpea dip with tahini, lemon, and olive oil, served with warm pita bread.",
        imageUrl: "https://images.unsplash.com/photo-1576698483491-8c43f0862543?auto=format&fit=crop&q=80&w=1868",
        prepTime: 15,
        cookTime: 0,
        servings: 6,
        difficulty: "Easy",
        isFeatured: false,
        rating: 45,
        ingredients: [
          "2 cans (15oz each) chickpeas, drained and rinsed",
          "1/4 cup fresh lemon juice",
          "1/4 cup tahini",
          "2 cloves garlic, minced",
          "2 tbsp olive oil, plus more for serving",
          "1/2 tsp ground cumin",
          "Salt to taste",
          "2-3 tbsp water",
          "Paprika for garnish",
          "Fresh parsley, chopped, for garnish",
          "Pita bread for serving"
        ],
        steps: [
          "In a food processor, combine chickpeas, lemon juice, tahini, garlic, olive oil, and cumin.",
          "Process until smooth, adding water as needed to reach desired consistency.",
          "Season with salt to taste and process again briefly.",
          "Transfer to a serving bowl and create a well in the center with the back of a spoon.",
          "Drizzle with additional olive oil and sprinkle with paprika and parsley.",
          "Serve with warm pita bread, cut into triangles."
        ],
        tips: [
          "For ultra-smooth hummus, remove the skins from the chickpeas before processing.",
          "Warm the chickpeas slightly before blending for a creamier texture.",
          "Customize with roasted red peppers, jalapeños, or extra garlic for flavor variations."
        ],
        calories: 180,
        protein: 7,
        carbs: 20,
        fat: 9
      }
    ];
    
    recipeData.forEach(recipe => {
      const id = this.currentRecipeId++;
      this.recipesMap.set(id, { ...recipe, id });
    });
  }
}

export const storage = new MemStorage();
