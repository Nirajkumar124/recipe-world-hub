const Footer = () => {
  return (
    <footer className="bg-dark text-light py-12 px-6">
      <div className="container mx-auto">
        <div className="grid md:grid-cols-4 gap-8">
          <div>
            <div className="flex items-center space-x-2 mb-4">
              <span className="text-primary text-3xl"><i className="ri-restaurant-line"></i></span>
              <span className="font-heading text-2xl font-bold">FlavorJourney</span>
            </div>
            <p className="font-body text-gray-400 mb-4">Explore global cuisines and discover authentic recipes from around the world.</p>
            <div className="flex space-x-4">
              <a href="#" className="text-gray-400 hover:text-primary transition">
                <i className="ri-facebook-fill text-xl"></i>
              </a>
              <a href="#" className="text-gray-400 hover:text-primary transition">
                <i className="ri-instagram-line text-xl"></i>
              </a>
              <a href="#" className="text-gray-400 hover:text-primary transition">
                <i className="ri-pinterest-line text-xl"></i>
              </a>
              <a href="#" className="text-gray-400 hover:text-primary transition">
                <i className="ri-youtube-line text-xl"></i>
              </a>
            </div>
          </div>
          
          <div>
            <h5 className="font-heading font-bold text-lg mb-4">Explore</h5>
            <ul className="space-y-2 font-body">
              <li><a href="#" className="text-gray-400 hover:text-primary transition">Popular Recipes</a></li>
              <li><a href="#cuisines" className="text-gray-400 hover:text-primary transition">Cuisines</a></li>
              <li><a href="#" className="text-gray-400 hover:text-primary transition">Meal Types</a></li>
              <li><a href="#" className="text-gray-400 hover:text-primary transition">Special Diets</a></li>
              <li><a href="#" className="text-gray-400 hover:text-primary transition">Cooking Techniques</a></li>
            </ul>
          </div>
          
          <div>
            <h5 className="font-heading font-bold text-lg mb-4">Learn</h5>
            <ul className="space-y-2 font-body">
              <li><a href="#" className="text-gray-400 hover:text-primary transition">Cooking Tips</a></li>
              <li><a href="#" className="text-gray-400 hover:text-primary transition">Kitchen Hacks</a></li>
              <li><a href="#" className="text-gray-400 hover:text-primary transition">Ingredient Guides</a></li>
              <li><a href="#" className="text-gray-400 hover:text-primary transition">Cooking Classes</a></li>
              <li><a href="#" className="text-gray-400 hover:text-primary transition">Video Tutorials</a></li>
            </ul>
          </div>
          
          <div>
            <h5 className="font-heading font-bold text-lg mb-4">Join Our Community</h5>
            <p className="font-body text-gray-400 mb-4">Subscribe to our newsletter for weekly recipe inspiration.</p>
            <form className="mb-4" onSubmit={(e) => e.preventDefault()}>
              <div className="flex">
                <input 
                  type="email" 
                  placeholder="Your email" 
                  className="px-4 py-2 rounded-l-lg w-full focus:outline-none text-dark"
                />
                <button 
                  type="submit" 
                  className="bg-primary hover:bg-opacity-90 text-white px-4 py-2 rounded-r-lg transition"
                >
                  Subscribe
                </button>
              </div>
            </form>
            <p className="text-xs text-gray-500">By subscribing, you agree to our Privacy Policy and Terms of Service.</p>
          </div>
        </div>
        
        <div className="border-t border-gray-700 mt-10 pt-6 flex flex-col md:flex-row justify-between items-center">
          <p className="text-gray-500 text-sm mb-4 md:mb-0">© {new Date().getFullYear()} FlavorJourney. All rights reserved.</p>
          <div className="flex space-x-6 text-sm text-gray-500">
            <a href="#" className="hover:text-gray-300 transition">Privacy Policy</a>
            <a href="#" className="hover:text-gray-300 transition">Terms of Service</a>
            <a href="#" className="hover:text-gray-300 transition">Contact Us</a>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
