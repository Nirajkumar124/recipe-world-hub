import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { Link, useParams } from "wouter";
import { Skeleton } from "@/components/ui/skeleton";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import useTextToSpeech, { VoiceType } from "@/lib/useTextToSpeech";
import { Recipe } from "@shared/schema";

const RecipePage = () => {
  const { id } = useParams<{ id: string }>();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [audioVisible, setAudioVisible] = useState(false);
  const [selectedVoiceType, setSelectedVoiceType] = useState<VoiceType>('default');
  const { 
    speak, 
    stop, 
    speaking, 
    progress, 
    togglePlayPause, 
    changeVoice, 
    availableVoices 
  } = useTextToSpeech();

  const recipeId = parseInt(id);

  const { data: recipe, isLoading, isError } = useQuery<Recipe>({
    queryKey: ['/api/recipes', recipeId],
    queryFn: async () => {
      const response = await fetch(`/api/recipes/${recipeId}`, {
        credentials: 'include',
      });
      if (!response.ok) {
        throw new Error('Failed to fetch recipe');
      }
      return response.json();
    },
    enabled: !!recipeId && !isNaN(recipeId),
    retry: 1,
  });

  // Function to find the cuisine by ID
  const getCuisineNameById = (id: number): string => {
    const cuisineNames = {
      1: "Indian",
      2: "Italian",
      3: "Chinese",
      4: "Mexican",
      5: "Japanese",
      6: "Thai",
      7: "French",
      8: "Mediterranean",
      9: "Korean",
      10: "Middle Eastern"
    };
    return cuisineNames[id as keyof typeof cuisineNames] || "Global";
  };

  // Handle voice type change
  const handleVoiceTypeChange = (value: VoiceType) => {
    if (value === selectedVoiceType) return; // Prevent unnecessary updates
    
    setSelectedVoiceType(value);
    changeVoice(value);
    
    // If already speaking, restart with new voice
    if (speaking && recipe) {
      const ingredientsText = "Ingredients: " + recipe.ingredients.join(", ");
      const stepsText = "Instructions: " + recipe.steps.join(". ");
      const fullText = `${recipe.name}. ${recipe.description}. ${ingredientsText}. ${stepsText}`;
      speak(fullText, value);
    }
  };

  const handlePlayAudio = () => {
    if (!recipe) return;
    
    setAudioVisible(true);
    
    // Create a text string for the recipe
    const ingredientsText = "Ingredients: " + recipe.ingredients.join(", ");
    const stepsText = "Instructions: " + recipe.steps.join(". ");
    const fullText = `${recipe.name}. ${recipe.description}. ${ingredientsText}. ${stepsText}`;
    
    speak(fullText, selectedVoiceType);
  };

  const formatTime = (seconds: number) => {
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = Math.floor(seconds % 60);
    return `${minutes}:${remainingSeconds < 10 ? '0' : ''}${remainingSeconds}`;
  };

  // Scroll to top only when component mounts
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);
  
  // Cleanup effect for text-to-speech
  useEffect(() => {
    return () => {
      // Don't use stop in the dependency array to avoid re-renders
      if (speaking) {
        stop();
      }
    };
  }, [speaking]);

  if (isLoading) {
    return (
      <div className="min-h-screen flex flex-col">
        <Header 
          mobileMenuOpen={mobileMenuOpen}
          setMobileMenuOpen={setMobileMenuOpen}
        />
        <main className="flex-grow container mx-auto px-6 py-12">
          <Skeleton className="h-64 w-full mb-8" />
          <Skeleton className="h-10 w-1/3 mb-4" />
          <Skeleton className="h-6 w-2/3 mb-8" />
          <div className="grid md:grid-cols-2 gap-8">
            <div>
              <Skeleton className="h-8 w-1/2 mb-4" />
              <Skeleton className="h-6 w-full mb-2" />
              <Skeleton className="h-6 w-full mb-2" />
              <Skeleton className="h-6 w-full mb-2" />
              <Skeleton className="h-6 w-3/4" />
            </div>
            <div>
              <Skeleton className="h-8 w-1/2 mb-4" />
              <Skeleton className="h-6 w-full mb-2" />
              <Skeleton className="h-6 w-full mb-2" />
              <Skeleton className="h-6 w-full mb-2" />
              <Skeleton className="h-6 w-3/4" />
            </div>
          </div>
        </main>
        <Footer />
      </div>
    );
  }

  if (!recipe) {
    return (
      <div className="min-h-screen flex flex-col">
        <Header 
          mobileMenuOpen={mobileMenuOpen}
          setMobileMenuOpen={setMobileMenuOpen}
        />
        <main className="flex-grow container mx-auto px-6 py-12 text-center">
          <h1 className="font-heading text-3xl font-bold mb-4">Recipe Not Found</h1>
          <p className="mb-8">The recipe you're looking for doesn't exist or has been removed.</p>
          <Link href="/" className="bg-primary hover:bg-opacity-90 text-light font-body font-semibold py-3 px-6 rounded-lg text-center transition">
            Return to Home
          </Link>
        </main>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col">
      <Header 
        mobileMenuOpen={mobileMenuOpen}
        setMobileMenuOpen={setMobileMenuOpen}
      />
      <main className="flex-grow">
        <div className="relative h-[50vh]">
          <img 
            src={recipe.imageUrl} 
            alt={recipe.name} 
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-dark bg-opacity-40"></div>
          <div className="absolute top-4 left-4 md:top-8 md:left-8">
            <Link
              href={`/cuisine/${recipe.cuisineId}`}
              className="flex items-center text-light bg-dark bg-opacity-50 hover:bg-opacity-70 rounded-full px-4 py-2 text-sm transition"
            >
              <i className="ri-arrow-left-line mr-2"></i>
              Back to {getCuisineNameById(recipe.cuisineId)} Cuisine
            </Link>
          </div>
        </div>
        
        <div className="container mx-auto px-6 py-12">
          <div className="flex flex-col md:flex-row md:items-start justify-between mb-8">
            <div>
              <span className="inline-block px-3 py-1 bg-secondary text-white text-sm font-body rounded-full mb-3">
                {getCuisineNameById(recipe.cuisineId)} Cuisine
              </span>
              <h1 className="font-heading text-4xl font-bold mb-2">{recipe.name}</h1>
              <p className="text-gray-600 max-w-2xl mb-6">{recipe.description}</p>
            </div>
            
            <div className="flex space-x-3 mt-3 md:mt-0">
              <button className="flex items-center space-x-1 px-3 py-1 bg-white rounded-lg border border-gray-200 text-sm hover:bg-gray-50">
                <i className="ri-heart-line text-muted"></i>
                <span>Save</span>
              </button>
              <button className="flex items-center space-x-1 px-3 py-1 bg-white rounded-lg border border-gray-200 text-sm hover:bg-gray-50">
                <i className="ri-share-line text-muted"></i>
                <span>Share</span>
              </button>
              <button className="flex items-center space-x-1 px-3 py-1 bg-white rounded-lg border border-gray-200 text-sm hover:bg-gray-50">
                <i className="ri-printer-line text-muted"></i>
                <span>Print</span>
              </button>
            </div>
          </div>
          
          <div className="flex flex-wrap gap-4 mb-8">
            <div className="flex items-center bg-primary/10 px-4 py-2 rounded-lg">
              <i className="ri-time-line text-primary mr-2"></i>
              <div>
                <p className="text-xs text-gray-500">Prep Time</p>
                <p className="font-semibold">{recipe.prepTime} mins</p>
              </div>
            </div>
            
            <div className="flex items-center bg-secondary/10 px-4 py-2 rounded-lg">
              <i className="ri-fire-line text-secondary mr-2"></i>
              <div>
                <p className="text-xs text-gray-500">Cook Time</p>
                <p className="font-semibold">{recipe.cookTime} mins</p>
              </div>
            </div>
            
            <div className="flex items-center bg-accent/10 px-4 py-2 rounded-lg">
              <i className="ri-group-line text-accent mr-2"></i>
              <div>
                <p className="text-xs text-gray-500">Servings</p>
                <p className="font-semibold">{recipe.servings} people</p>
              </div>
            </div>
            
            <div className="flex items-center bg-muted/10 px-4 py-2 rounded-lg">
              <i className="ri-bar-chart-line text-muted mr-2"></i>
              <div>
                <p className="text-xs text-gray-500">Difficulty</p>
                <p className="font-semibold">{recipe.difficulty}</p>
              </div>
            </div>
          </div>
          
          <div className="text-center mb-8">
            {!audioVisible ? (
              <div>
                <div className="mb-4 bg-gray-50 p-4 rounded-lg max-w-md mx-auto">
                  <h4 className="font-heading text-md font-medium mb-3">Voice Preference</h4>
                  <RadioGroup 
                    defaultValue="default" 
                    value={selectedVoiceType}
                    onValueChange={(value) => handleVoiceTypeChange(value as VoiceType)}
                    className="flex justify-center space-x-8"
                  >
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="male" id="male" />
                      <Label htmlFor="male" className="cursor-pointer">Male</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="female" id="female" />
                      <Label htmlFor="female" className="cursor-pointer">Female</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="default" id="default" />
                      <Label htmlFor="default" className="cursor-pointer">Default</Label>
                    </div>
                  </RadioGroup>
                </div>
                <button 
                  onClick={handlePlayAudio}
                  className="bg-primary hover:bg-opacity-90 text-light font-body font-semibold py-2 px-5 rounded-lg flex items-center mx-auto transition"
                >
                  <i className="ri-volume-up-line mr-2"></i>
                  <span>Listen to Recipe</span>
                </button>
              </div>
            ) : (
              <div className="mt-4 bg-gray-100 p-4 rounded-lg max-w-md mx-auto">
                <div className="flex items-center justify-between mb-3">
                  <h4 className="font-heading text-md font-medium">Audio Player</h4>
                  <div className="flex items-center space-x-3">
                    <RadioGroup 
                      value={selectedVoiceType}
                      onValueChange={(value) => handleVoiceTypeChange(value as VoiceType)}
                      className="flex space-x-4"
                    >
                      <div className="flex items-center space-x-1">
                        <RadioGroupItem value="male" id="male-playing" />
                        <Label htmlFor="male-playing" className="text-xs cursor-pointer">Male</Label>
                      </div>
                      <div className="flex items-center space-x-1">
                        <RadioGroupItem value="female" id="female-playing" />
                        <Label htmlFor="female-playing" className="text-xs cursor-pointer">Female</Label>
                      </div>
                    </RadioGroup>
                  </div>
                </div>
                
                <div className="flex items-center justify-center space-x-4">
                  <button 
                    onClick={() => {
                      stop();
                      if (recipe) {
                        const ingredientsText = "Ingredients: " + recipe.ingredients.join(", ");
                        const stepsText = "Instructions: " + recipe.steps.join(". ");
                        const fullText = `${recipe.name}. ${recipe.description}. ${ingredientsText}. ${stepsText}`;
                        speak(fullText, selectedVoiceType);
                      }
                    }}
                    className="text-dark hover:text-primary"
                  >
                    <i className="ri-restart-line"></i>
                  </button>
                  <button 
                    onClick={togglePlayPause}
                    className="bg-primary text-light w-10 h-10 rounded-full flex items-center justify-center hover:bg-opacity-90"
                  >
                    <i className={`ri-${speaking ? 'pause' : 'play'}-line`}></i>
                  </button>
                  <button 
                    onClick={() => {
                      stop(); 
                      setAudioVisible(false);
                    }}
                    className="text-dark hover:text-primary"
                  >
                    <i className="ri-close-line"></i>
                  </button>
                </div>
                
                <div className="mt-2 flex items-center space-x-2">
                  <span className="text-xs">{formatTime(progress.current)}</span>
                  <div className="h-1 bg-gray-300 rounded-full flex-1">
                    <div 
                      className="h-full bg-primary rounded-full" 
                      style={{ width: `${(progress.current / progress.total) * 100}%` }}
                    ></div>
                  </div>
                  <span className="text-xs">{formatTime(progress.total)}</span>
                </div>
              </div>
            )}
          </div>

          <div className="grid md:grid-cols-2 gap-8 mb-8">
            <div>
              <h4 className="font-heading text-xl font-bold mb-4 flex items-center">
                <i className="ri-list-check text-primary mr-2"></i>
                Ingredients
              </h4>
              <ul className="space-y-3">
                {recipe && recipe.ingredients && recipe.ingredients.length > 0 ? (
                  recipe.ingredients.map((ingredient, index) => (
                    <li key={index} className="flex items-start">
                      <i className="ri-checkbox-circle-line text-secondary mt-0.5 mr-2"></i>
                      <span className="font-body">{ingredient}</span>
                    </li>
                  ))
                ) : (
                  <li>No ingredients available for this recipe.</li>
                )}
              </ul>
            </div>
            
            <div>
              <h4 className="font-heading text-xl font-bold mb-4 flex items-center">
                <i className="ri-restaurant-line text-primary mr-2"></i>
                Preparation
              </h4>
              <ol className="space-y-4">
                {recipe && recipe.steps && recipe.steps.length > 0 ? (
                  recipe.steps.map((step, index) => (
                    <li key={index} className="flex">
                      <div className="flex-shrink-0 bg-primary text-light w-6 h-6 rounded-full flex items-center justify-center font-bold text-sm mr-3 mt-0.5">
                        {index + 1}
                      </div>
                      <p className="font-body">{step}</p>
                    </li>
                  ))
                ) : (
                  <li>No preparation steps available for this recipe.</li>
                )}
              </ol>
            </div>
          </div>
          
          {recipe && recipe.tips && recipe.tips.length > 0 && (
            <div className="bg-gray-50 p-6 rounded-lg mb-8">
              <h4 className="font-heading text-lg font-bold mb-3 flex items-center">
                <i className="ri-lightbulb-line text-accent mr-2"></i>
                Chef's Tips
              </h4>
              <ul className="space-y-2">
                {recipe.tips.map((tip, index) => (
                  <li key={index} className="flex items-start">
                    <i className="ri-arrow-right-circle-line text-accent mt-0.5 mr-2"></i>
                    <span className="font-body">{tip}</span>
                  </li>
                ))}
              </ul>
            </div>
          )}
          
          {recipe && (recipe.calories || recipe.protein || recipe.carbs || recipe.fat) && (
            <div className="border-t border-gray-200 pt-8">
              <h4 className="font-heading text-lg font-bold mb-4">Nutritional Information</h4>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                {recipe.calories && (
                  <div className="bg-white p-3 rounded-lg border border-gray-200 text-center">
                    <p className="text-sm text-gray-500">Calories</p>
                    <p className="font-bold">{recipe.calories} kcal</p>
                  </div>
                )}
                {recipe.protein && (
                  <div className="bg-white p-3 rounded-lg border border-gray-200 text-center">
                    <p className="text-sm text-gray-500">Protein</p>
                    <p className="font-bold">{recipe.protein}g</p>
                  </div>
                )}
                {recipe.carbs && (
                  <div className="bg-white p-3 rounded-lg border border-gray-200 text-center">
                    <p className="text-sm text-gray-500">Carbs</p>
                    <p className="font-bold">{recipe.carbs}g</p>
                  </div>
                )}
                {recipe.fat && (
                  <div className="bg-white p-3 rounded-lg border border-gray-200 text-center">
                    <p className="text-sm text-gray-500">Fat</p>
                    <p className="font-bold">{recipe.fat}g</p>
                  </div>
                )}
              </div>
            </div>
          )}
          
          <div className="border-t border-gray-200 mt-8 pt-8">
            {recipe && recipe.cuisineId && (
              <Link
                href={`/cuisine/${recipe.cuisineId}`}
                className="text-primary hover:underline font-semibold flex items-center"
              >
                <i className="ri-arrow-left-line mr-1"></i> Back to {getCuisineNameById(recipe.cuisineId)} Cuisine
              </Link>
            )}
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
};

export default RecipePage;