import { pgTable, text, serial, integer, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const cuisines = pgTable("cuisines", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description").notNull(),
  imageUrl: text("image_url").notNull(),
  recipeCount: integer("recipe_count").notNull().default(0),
});

export const recipes = pgTable("recipes", {
  id: serial("id").primaryKey(),
  cuisineId: integer("cuisine_id").notNull(),
  name: text("name").notNull(),
  description: text("description").notNull(),
  imageUrl: text("image_url").notNull(),
  prepTime: integer("prep_time").notNull(),
  cookTime: integer("cook_time").notNull(),
  servings: integer("servings").notNull(),
  difficulty: text("difficulty").notNull(),
  isFeatured: boolean("is_featured").notNull().default(false),
  rating: integer("rating").notNull().default(0),
  ingredients: text("ingredients").array().notNull(),
  steps: text("steps").array().notNull(),
  tips: text("tips").array(),
  calories: integer("calories"),
  protein: integer("protein"),
  carbs: integer("carbs"),
  fat: integer("fat"),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export const insertCuisineSchema = createInsertSchema(cuisines).pick({
  name: true,
  description: true,
  imageUrl: true,
  recipeCount: true,
});

export const insertRecipeSchema = createInsertSchema(recipes).omit({
  id: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export type InsertCuisine = z.infer<typeof insertCuisineSchema>;
export type Cuisine = typeof cuisines.$inferSelect;

export type InsertRecipe = z.infer<typeof insertRecipeSchema>;
export type Recipe = typeof recipes.$inferSelect;
