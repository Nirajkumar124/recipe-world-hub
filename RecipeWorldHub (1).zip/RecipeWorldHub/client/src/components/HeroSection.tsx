import { Link } from "wouter";

const HeroSection = () => {
  return (
    <section className="relative h-[70vh] bg-center bg-cover flex items-center" style={{ backgroundImage: "url('https://images.unsplash.com/photo-1504674900247-0877df9cc836?auto=format&fit=crop&q=80&w=1770')" }}>
      <div className="absolute inset-0 bg-dark bg-opacity-60"></div>
      <div className="container mx-auto px-6 relative z-10">
        <div className="max-w-2xl">
          <h1 className="font-heading text-4xl md:text-6xl font-bold text-light mb-4">Explore the World Through Flavors</h1>
          <p className="font-body text-xl text-light opacity-90 mb-8">Discover authentic recipes from around the globe. Learn, cook, and savor the diverse tastes of international cuisines.</p>
          <div className="flex flex-col sm:flex-row space-y-4 sm:space-y-0 sm:space-x-4">
            <a href="#cuisines" className="bg-primary hover:bg-opacity-90 text-light font-body font-semibold py-3 px-6 rounded-lg text-center transition">Explore Cuisines</a>
            <Link href="#" className="bg-transparent border-2 border-light text-light hover:bg-light hover:text-dark font-body font-semibold py-3 px-6 rounded-lg text-center transition">Today's Picks</Link>
          </div>
        </div>
      </div>
    </section>
  );
};

export default HeroSection;
