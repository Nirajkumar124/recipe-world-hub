import { Link } from "wouter";
import { Recipe } from "@shared/schema";

interface FeaturedRecipeProps {
  recipe: Recipe;
  onViewRecipe: () => void;
}

const FeaturedRecipe = ({ recipe, onViewRecipe }: FeaturedRecipeProps) => {
  // Function to find the cuisine by ID (this could be improved by passing the actual cuisine)
  const getCuisineNameById = (id: number): string => {
    const cuisineNames = {
      1: "Indian",
      2: "Italian",
      3: "Chinese",
      4: "Mexican",
      5: "Japanese",
      6: "Thai",
      7: "French",
      8: "Mediterranean",
      9: "Korean",
      10: "Middle Eastern"
    };
    return cuisineNames[id as keyof typeof cuisineNames] || "Global";
  };

  return (
    <section className="py-16 px-6 bg-gradient-to-r from-secondary/10 to-primary/10">
      <div className="container mx-auto">
        <div className="flex justify-between items-center mb-8">
          <h2 className="font-heading text-3xl font-bold text-dark">Featured Recipe</h2>
          <span className="font-accent text-xl text-primary">Chef's Special</span>
        </div>
        
        <div className="bg-white rounded-xl shadow-lg overflow-hidden grid md:grid-cols-2">
          <div className="h-64 md:h-auto">
            <img 
              src={recipe.imageUrl} 
              alt={recipe.name} 
              className="w-full h-full object-cover"
            />
          </div>
          <div className="p-8">
            <div className="flex justify-between items-start">
              <div>
                <span className="inline-block px-3 py-1 bg-secondary text-white text-sm font-body rounded-full mb-3">
                  {getCuisineNameById(recipe.cuisineId)} Cuisine
                </span>
                <h3 className="font-heading text-2xl font-bold mb-2">{recipe.name}</h3>
              </div>
              <button className="text-muted hover:text-primary">
                <i className="ri-heart-line text-xl"></i>
              </button>
            </div>
            
            <div className="flex space-x-6 mb-4">
              <div className="flex items-center">
                <i className="ri-time-line text-muted mr-2"></i>
                <span className="text-sm font-body">{recipe.prepTime + recipe.cookTime} mins</span>
              </div>
              <div className="flex items-center">
                <i className="ri-flame-line text-primary mr-2"></i>
                <span className="text-sm font-body">{recipe.difficulty}</span>
              </div>
              <div className="flex items-center">
                <i className="ri-group-line text-muted mr-2"></i>
                <span className="text-sm font-body">{recipe.servings} servings</span>
              </div>
            </div>
            
            <p className="font-body text-gray-600 mb-6">{recipe.description}</p>
            
            <button 
              className="bg-primary hover:bg-opacity-90 text-light font-body font-semibold py-2 px-5 rounded-lg flex items-center transition"
              onClick={onViewRecipe}
            >
              <span>View Recipe</span>
              <i className="ri-arrow-right-line ml-2"></i>
            </button>
          </div>
        </div>
      </div>
    </section>
  );
};

export default FeaturedRecipe;
