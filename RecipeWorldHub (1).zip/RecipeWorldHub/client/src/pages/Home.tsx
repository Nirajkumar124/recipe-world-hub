import { useState } from "react";
import { useLocation } from "wouter";
import { useQuery } from "@tanstack/react-query";
import Header from "@/components/Header";
import HeroSection from "@/components/HeroSection";
import FeaturedRecipe from "@/components/FeaturedRecipe";
import CuisinesSection from "@/components/CuisinesSection";
import Footer from "@/components/Footer";
import { Cuisine, Recipe } from "@shared/schema";

const Home = () => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [, setLocation] = useLocation();

  const { data: cuisines = [], isLoading: cuisinesLoading } = useQuery<Cuisine[]>({
    queryKey: ['/api/cuisines'],
  });

  const { data: featuredRecipe, isLoading: featuredRecipeLoading } = useQuery<Recipe>({
    queryKey: ['/api/recipes/featured'],
  });

  const handleCuisineClick = (cuisine: Cuisine) => {
    setLocation(`/cuisine/${cuisine.id}`);
  };

  const handleRecipeClick = (recipe: Recipe) => {
    setLocation(`/recipe/${recipe.id}`);
  };

  return (
    <div className="min-h-screen flex flex-col">
      <Header 
        mobileMenuOpen={mobileMenuOpen}
        setMobileMenuOpen={setMobileMenuOpen}
      />
      <main className="flex-grow">
        <HeroSection />
        {featuredRecipe && <FeaturedRecipe recipe={featuredRecipe} onViewRecipe={() => handleRecipeClick(featuredRecipe)} />}
        <CuisinesSection 
          cuisines={cuisines}
          isLoading={cuisinesLoading}
          onCuisineClick={handleCuisineClick}
        />
      </main>
      <Footer />
    </div>
  );
};

export default Home;
