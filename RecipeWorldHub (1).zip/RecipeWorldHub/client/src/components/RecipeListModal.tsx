import { Cuisine, Recipe } from "@shared/schema";
import { Skeleton } from "@/components/ui/skeleton";

interface RecipeListModalProps {
  isOpen: boolean;
  onClose: () => void;
  cuisine: Cuisine | null;
  recipes: Recipe[];
  isLoading: boolean;
  onRecipeClick: (recipe: Recipe) => void;
}

const RecipeListModal = ({ 
  isOpen, 
  onClose, 
  cuisine, 
  recipes, 
  isLoading, 
  onRecipeClick 
}: RecipeListModalProps) => {
  // Formats a rating from 0-50 to 0-5 with a single decimal place
  const formatRating = (rating: number) => {
    return (rating / 10).toFixed(1);
  };

  if (!cuisine) return null;

  return (
    <div 
      className={`fixed inset-0 bg-dark bg-opacity-70 flex items-center justify-center z-50 modal ${isOpen ? 'opacity-100 pointer-events-auto' : 'opacity-0 pointer-events-none'}`}
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div className="bg-light w-full max-w-4xl max-h-[90vh] overflow-y-auto rounded-xl shadow-2xl transform transition-transform">
        <div className="sticky top-0 bg-light z-10 border-b border-gray-200">
          <div className="flex justify-between items-center p-6">
            <div>
              <h3 className="font-heading text-2xl font-bold">{cuisine.name} Cuisine</h3>
              <p className="font-body text-gray-600">{cuisine.description}</p>
            </div>
            <button 
              onClick={onClose}
              className="text-gray-500 hover:text-primary text-2xl"
            >
              <i className="ri-close-line"></i>
            </button>
          </div>
        </div>
        
        <div className="p-6">
          {isLoading ? (
            // Loading skeletons
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {Array(4).fill(0).map((_, index) => (
                <div key={index} className="bg-white rounded-lg overflow-hidden shadow-md flex">
                  <Skeleton className="w-1/3 h-32" />
                  <div className="w-2/3 p-4">
                    <Skeleton className="h-6 w-3/4 mb-2" />
                    <Skeleton className="h-4 w-1/2 mb-2" />
                    <Skeleton className="h-4 w-full" />
                  </div>
                </div>
              ))}
            </div>
          ) : recipes.length === 0 ? (
            // No recipes message
            <div className="text-center py-10">
              <p className="text-lg font-body text-gray-500">No recipes found for this cuisine.</p>
            </div>
          ) : (
            // Recipe cards
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {recipes.map(recipe => (
                <div 
                  key={recipe.id}
                  className="recipe-card bg-white rounded-lg overflow-hidden shadow-md flex cursor-pointer"
                  onClick={() => onRecipeClick(recipe)}
                >
                  <div className="w-1/3 h-full overflow-hidden">
                    <img 
                      src={recipe.imageUrl} 
                      alt={recipe.name}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div className="w-2/3 p-4">
                    <h4 className="font-heading font-bold text-lg mb-1">{recipe.name}</h4>
                    <div className="flex items-center text-sm mb-2">
                      <span className="flex items-center mr-3">
                        <i className="ri-time-line text-muted mr-1"></i>
                        {recipe.prepTime + recipe.cookTime} mins
                      </span>
                      <span className="flex items-center">
                        <i className="ri-star-fill text-accent mr-1"></i>
                        {formatRating(recipe.rating)}
                      </span>
                    </div>
                    <p className="text-sm text-gray-500 line-clamp-2">{recipe.description}</p>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default RecipeListModal;
