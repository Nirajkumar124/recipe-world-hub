import { useState } from "react";
import { Recipe } from "@shared/schema";
import useTextToSpeech from "@/lib/useTextToSpeech";

interface RecipeDetailModalProps {
  isOpen: boolean;
  onClose: () => void;
  recipe: Recipe | null;
}

const RecipeDetailModal = ({ isOpen, onClose, recipe }: RecipeDetailModalProps) => {
  const [audioVisible, setAudioVisible] = useState(false);
  const { speak, stop, speaking, progress, togglePlayPause } = useTextToSpeech();

  // Function to find the cuisine by ID (this could be improved by passing the actual cuisine)
  const getCuisineNameById = (id: number): string => {
    const cuisineNames = {
      1: "Indian",
      2: "Italian",
      3: "Chinese",
      4: "Mexican",
      5: "Japanese",
      6: "Thai",
      7: "French",
      8: "Mediterranean",
      9: "Korean",
      10: "Middle Eastern"
    };
    return cuisineNames[id as keyof typeof cuisineNames] || "Global";
  };

  const handlePlayAudio = () => {
    if (!recipe) return;
    
    setAudioVisible(true);
    
    // Create a text string for the recipe
    const ingredientsText = "Ingredients: " + recipe.ingredients.join(", ");
    const stepsText = "Instructions: " + recipe.steps.join(". ");
    const fullText = `${recipe.name}. ${recipe.description}. ${ingredientsText}. ${stepsText}`;
    
    speak(fullText);
  };

  const formatTime = (seconds: number) => {
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = Math.floor(seconds % 60);
    return `${minutes}:${remainingSeconds < 10 ? '0' : ''}${remainingSeconds}`;
  };

  // If no recipe or modal is closed, don't render anything
  if (!recipe || !isOpen) return null;

  return (
    <div 
      className={`fixed inset-0 bg-dark bg-opacity-70 flex items-center justify-center z-50 modal ${isOpen ? 'opacity-100 pointer-events-auto' : 'opacity-0 pointer-events-none'}`}
      onClick={(e) => {
        if (e.target === e.currentTarget) {
          stop();
          onClose();
        }
      }}
    >
      <div className="bg-light w-full max-w-4xl max-h-[90vh] overflow-y-auto rounded-xl shadow-2xl transform transition-transform">
        <div className="relative">
          <div className="h-64 w-full">
            <img 
              src={recipe.imageUrl} 
              alt={recipe.name} 
              className="w-full h-full object-cover"
            />
          </div>
          <button 
            onClick={() => {
              stop();
              onClose();
            }}
            className="absolute top-4 right-4 bg-dark bg-opacity-50 text-light rounded-full w-10 h-10 flex items-center justify-center hover:bg-opacity-70"
          >
            <i className="ri-close-line"></i>
          </button>
        </div>
        
        <div className="p-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between mb-6">
            <div>
              <span className="inline-block px-3 py-1 bg-secondary text-white text-sm font-body rounded-full mb-2">
                {getCuisineNameById(recipe.cuisineId)} Cuisine
              </span>
              <h3 className="font-heading text-3xl font-bold">{recipe.name}</h3>
            </div>
            
            <div className="flex space-x-3 mt-3 sm:mt-0">
              <button className="flex items-center space-x-1 px-3 py-1 bg-white rounded-lg border border-gray-200 text-sm hover:bg-gray-50">
                <i className="ri-heart-line text-muted"></i>
                <span>Save</span>
              </button>
              <button className="flex items-center space-x-1 px-3 py-1 bg-white rounded-lg border border-gray-200 text-sm hover:bg-gray-50">
                <i className="ri-share-line text-muted"></i>
                <span>Share</span>
              </button>
              <button className="flex items-center space-x-1 px-3 py-1 bg-white rounded-lg border border-gray-200 text-sm hover:bg-gray-50">
                <i className="ri-printer-line text-muted"></i>
                <span>Print</span>
              </button>
            </div>
          </div>
          
          <div className="flex flex-wrap gap-4 mb-8">
            <div className="flex items-center bg-primary/10 px-4 py-2 rounded-lg">
              <i className="ri-time-line text-primary mr-2"></i>
              <div>
                <p className="text-xs text-gray-500">Prep Time</p>
                <p className="font-semibold">{recipe.prepTime} mins</p>
              </div>
            </div>
            
            <div className="flex items-center bg-secondary/10 px-4 py-2 rounded-lg">
              <i className="ri-fire-line text-secondary mr-2"></i>
              <div>
                <p className="text-xs text-gray-500">Cook Time</p>
                <p className="font-semibold">{recipe.cookTime} mins</p>
              </div>
            </div>
            
            <div className="flex items-center bg-accent/10 px-4 py-2 rounded-lg">
              <i className="ri-group-line text-accent mr-2"></i>
              <div>
                <p className="text-xs text-gray-500">Servings</p>
                <p className="font-semibold">{recipe.servings} people</p>
              </div>
            </div>
            
            <div className="flex items-center bg-muted/10 px-4 py-2 rounded-lg">
              <i className="ri-bar-chart-line text-muted mr-2"></i>
              <div>
                <p className="text-xs text-gray-500">Difficulty</p>
                <p className="font-semibold">{recipe.difficulty}</p>
              </div>
            </div>
          </div>
          
          <div className="text-center mb-6">
            {!audioVisible ? (
              <button 
                onClick={handlePlayAudio}
                className="bg-primary hover:bg-opacity-90 text-light font-body font-semibold py-2 px-5 rounded-lg flex items-center mx-auto transition"
              >
                <i className="ri-volume-up-line mr-2"></i>
                <span>Listen to Recipe</span>
              </button>
            ) : (
              <div className="mt-4 bg-gray-100 p-3 rounded-lg max-w-md mx-auto">
                <div className="flex items-center justify-center space-x-4">
                  <button className="text-dark hover:text-primary">
                    <i className="ri-skip-back-line"></i>
                  </button>
                  <button 
                    onClick={togglePlayPause}
                    className="bg-primary text-light w-10 h-10 rounded-full flex items-center justify-center hover:bg-opacity-90"
                  >
                    <i className={`ri-${speaking ? 'pause' : 'play'}-line`}></i>
                  </button>
                  <button className="text-dark hover:text-primary">
                    <i className="ri-skip-forward-line"></i>
                  </button>
                </div>
                <div className="mt-2 flex items-center space-x-2">
                  <span className="text-xs">{formatTime(progress.current)}</span>
                  <div className="h-1 bg-gray-300 rounded-full flex-1">
                    <div 
                      className="h-full bg-primary rounded-full" 
                      style={{ width: `${(progress.current / progress.total) * 100}%` }}
                    ></div>
                  </div>
                  <span className="text-xs">{formatTime(progress.total)}</span>
                </div>
              </div>
            )}
          </div>

          <div className="grid md:grid-cols-2 gap-8 mb-8">
            <div>
              <h4 className="font-heading text-xl font-bold mb-4 flex items-center">
                <i className="ri-list-check text-primary mr-2"></i>
                Ingredients
              </h4>
              <ul className="space-y-3">
                {recipe.ingredients.map((ingredient, index) => (
                  <li key={index} className="flex items-start">
                    <i className="ri-checkbox-circle-line text-secondary mt-0.5 mr-2"></i>
                    <span className="font-body">{ingredient}</span>
                  </li>
                ))}
              </ul>
            </div>
            
            <div>
              <h4 className="font-heading text-xl font-bold mb-4 flex items-center">
                <i className="ri-restaurant-line text-primary mr-2"></i>
                Preparation
              </h4>
              <ol className="space-y-4">
                {recipe.steps.map((step, index) => (
                  <li key={index} className="flex">
                    <div className="flex-shrink-0 bg-primary text-light w-6 h-6 rounded-full flex items-center justify-center font-bold text-sm mr-3 mt-0.5">
                      {index + 1}
                    </div>
                    <p className="font-body">{step}</p>
                  </li>
                ))}
              </ol>
            </div>
          </div>
          
          {recipe.tips && recipe.tips.length > 0 && (
            <div className="bg-gray-50 p-4 rounded-lg mb-6">
              <h4 className="font-heading text-lg font-bold mb-2 flex items-center">
                <i className="ri-lightbulb-line text-accent mr-2"></i>
                Chef's Tips
              </h4>
              <ul className="space-y-2">
                {recipe.tips.map((tip, index) => (
                  <li key={index} className="flex items-start">
                    <i className="ri-arrow-right-circle-line text-accent mt-0.5 mr-2"></i>
                    <span className="font-body">{tip}</span>
                  </li>
                ))}
              </ul>
            </div>
          )}
          
          {(recipe.calories || recipe.protein || recipe.carbs || recipe.fat) && (
            <div className="border-t border-gray-200 pt-6">
              <h4 className="font-heading text-lg font-bold mb-4">Nutritional Information</h4>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                {recipe.calories && (
                  <div className="bg-white p-3 rounded-lg border border-gray-200 text-center">
                    <p className="text-sm text-gray-500">Calories</p>
                    <p className="font-bold">{recipe.calories} kcal</p>
                  </div>
                )}
                {recipe.protein && (
                  <div className="bg-white p-3 rounded-lg border border-gray-200 text-center">
                    <p className="text-sm text-gray-500">Protein</p>
                    <p className="font-bold">{recipe.protein}g</p>
                  </div>
                )}
                {recipe.carbs && (
                  <div className="bg-white p-3 rounded-lg border border-gray-200 text-center">
                    <p className="text-sm text-gray-500">Carbs</p>
                    <p className="font-bold">{recipe.carbs}g</p>
                  </div>
                )}
                {recipe.fat && (
                  <div className="bg-white p-3 rounded-lg border border-gray-200 text-center">
                    <p className="text-sm text-gray-500">Fat</p>
                    <p className="font-bold">{recipe.fat}g</p>
                  </div>
                )}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default RecipeDetailModal;
