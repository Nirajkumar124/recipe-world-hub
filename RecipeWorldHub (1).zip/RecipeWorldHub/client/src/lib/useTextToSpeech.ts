import { useState, useEffect, useRef, useCallback } from 'react';

export interface TextToSpeechProgress {
  current: number;
  total: number;
}

export type VoiceType = 'male' | 'female' | 'default';

export interface Voice {
  id: string;
  name: string;
  lang: string;
  gender: 'male' | 'female' | 'unknown';
  voiceObj: SpeechSynthesisVoice;
}

export const useTextToSpeech = () => {
  const [speaking, setSpeaking] = useState(false);
  const [progress, setProgress] = useState<TextToSpeechProgress>({ current: 0, total: 0 });
  const [availableVoices, setAvailableVoices] = useState<Voice[]>([]);
  const [selectedVoice, setSelectedVoice] = useState<Voice | null>(null);
  const [loading, setLoading] = useState(false);
  
  const speechSynthesis = window.speechSynthesis;
  const utteranceRef = useRef<SpeechSynthesisUtterance | null>(null);
  const intervalRef = useRef<number | null>(null);

  // Load available voices
  const loadVoices = useCallback(() => {
    setLoading(true);
    try {
      if (speechSynthesis) {
        let voiceList = speechSynthesis.getVoices();
        
        // If no voices are available yet, try again after a delay
        if (voiceList.length === 0) {
          setTimeout(() => {
            voiceList = speechSynthesis.getVoices();
            processVoices(voiceList);
          }, 100);
        } else {
          processVoices(voiceList);
        }
      }
    } catch (error) {
      console.error("Error loading voices:", error);
    } finally {
      setLoading(false);
    }
  }, []);

  // Process the list of voices
  const processVoices = (voiceList: SpeechSynthesisVoice[]) => {
    // Check if there are any voices
    if (!voiceList || voiceList.length === 0) {
      console.log("No voices available yet");
      return;
    }
    
    // Only include English voices if available, otherwise use all
    let filteredVoices = voiceList.filter(voice => 
      voice.lang.includes('en') || voice.lang.includes('US') || voice.lang.includes('GB')
    );
    
    // If no English voices are found, use all available
    if (filteredVoices.length === 0) {
      console.log("No English voices found, using all available voices");
      filteredVoices = voiceList;
    }
    
    // Create a default female and male voice if none exists
    let hasFemaleVoice = false;
    let hasMaleVoice = false;
    
    // Map to our Voice type
    const processedVoices: Voice[] = filteredVoices.map(voice => {
      // Try to determine gender based on voice name (imperfect but a reasonable heuristic)
      let gender: 'male' | 'female' | 'unknown' = 'unknown';
      const name = voice.name.toLowerCase();
      
      if (
        name.includes('female') || 
        name.includes('woman') || 
        name.includes('girl') ||
        name.includes('samantha') ||
        name.includes('victoria') ||
        name.includes('karen') ||
        name.includes('tessa') ||
        name.includes('monica') ||
        name.includes('amy') ||
        name.includes('lisa')
      ) {
        gender = 'female';
        hasFemaleVoice = true;
      } else if (
        name.includes('male') ||
        name.includes('man') ||
        name.includes('guy') ||
        name.includes('david') ||
        name.includes('mark') ||
        name.includes('daniel') ||
        name.includes('james') ||
        name.includes('tom') ||
        name.includes('alex')
      ) {
        gender = 'male';
        hasMaleVoice = true;
      }
      
      return {
        id: voice.voiceURI,
        name: voice.name,
        lang: voice.lang,
        gender,
        voiceObj: voice
      };
    });
    
    // If we don't have a clear male or female voice, assign the first voice to male and second to female if available
    if (!hasMaleVoice && processedVoices.length > 0) {
      processedVoices[0].gender = 'male';
    }
    
    if (!hasFemaleVoice && processedVoices.length > 1) {
      processedVoices[1].gender = 'female';
    } else if (!hasFemaleVoice && processedVoices.length === 1) {
      // If there's only one voice, mark it as both male and female
      processedVoices[0].gender = 'female';
    }
    
    console.log("Available voices:", processedVoices);
    setAvailableVoices(processedVoices);
    
    // Set a default voice if none is selected yet
    if (!selectedVoice && processedVoices.length > 0) {
      setSelectedVoice(processedVoices[0]);
    }
  };

  // Load voices when available
  useEffect(() => {
    loadVoices();
    
    // Chrome and some other browsers need this event
    if (speechSynthesis) {
      speechSynthesis.onvoiceschanged = loadVoices;
    }
    
    return () => {
      if (speechSynthesis) {
        speechSynthesis.onvoiceschanged = null;
      }
    };
  }, [loadVoices]);

  // Cleanup function
  const cleanup = () => {
    if (intervalRef.current) {
      clearInterval(intervalRef.current);
      intervalRef.current = null;
    }
  };

  // Stop speech
  const stop = () => {
    if (speechSynthesis) {
      speechSynthesis.cancel();
      setSpeaking(false);
      cleanup();
      setProgress({ current: 0, total: 0 });
    }
  };

  // Toggle play/pause
  const togglePlayPause = () => {
    if (speechSynthesis) {
      if (speaking) {
        speechSynthesis.pause();
        setSpeaking(false);
        cleanup();
      } else {
        speechSynthesis.resume();
        setSpeaking(true);
        startProgressTracking();
      }
    }
  };

  // Track progress
  const startProgressTracking = () => {
    if (intervalRef.current) {
      clearInterval(intervalRef.current);
    }

    intervalRef.current = window.setInterval(() => {
      if (utteranceRef.current) {
        // SpeechSynthesisUtterance doesn't have a native 'elapsedTime' property
        // Instead, we increment our own timer counter
        setProgress(prev => ({ ...prev, current: prev.current + 0.1 }));
      }
    }, 100);
  };

  // Change voice type (male/female)
  const changeVoice = (voiceType: VoiceType) => {
    // If default, just use the first available voice
    if (voiceType === 'default' && availableVoices.length > 0) {
      setSelectedVoice(availableVoices[0]);
      return;
    }
    
    // Find a voice of the specified gender
    const voice = availableVoices.find(v => v.gender === voiceType);
    if (voice) {
      setSelectedVoice(voice);
    } else {
      // Fallback to any available voice if no match for the requested gender
      if (availableVoices.length > 0) {
        setSelectedVoice(availableVoices[0]);
      }
    }
  };

  // Speak text with the selected voice
  const speak = (text: string, voiceType?: VoiceType) => {
    if (!window.speechSynthesis) {
      console.warn("Speech synthesis not supported in this browser");
      return;
    }
    
    try {
      // Make sure we have the latest voices
      const voices = window.speechSynthesis.getVoices();
      if (voices.length === 0) {
        console.log("No voices available, trying to load voices");
        loadVoices();
      }
      
      // Cancel any ongoing speech
      stop();
      
      // Create a new utterance
      const utterance = new SpeechSynthesisUtterance(text);
      utteranceRef.current = utterance;
      
      // If a voice type is specified, try to use it
      if (voiceType) {
        changeVoice(voiceType);
      }
      
      console.log("Using voice type:", voiceType || 'default', "Selected voice:", selectedVoice);
      
      // Break the text into smaller chunks to avoid browser limitations
      const chunks = chunkText(text, 200); // Split into chunks of ~200 characters
      
      // Set up the first chunk
      const firstChunk = chunks.shift() || "";
      const firstUtterance = new SpeechSynthesisUtterance(firstChunk);
      
      // Configure the utterance
      if (selectedVoice) {
        firstUtterance.voice = selectedVoice.voiceObj;
      } else if (availableVoices.length > 0) {
        // Fallback to first available voice
        firstUtterance.voice = availableVoices[0].voiceObj;
      }
      
      // Set pitch and rate
      firstUtterance.pitch = 1;
      firstUtterance.rate = 0.9; // Slightly slower for better comprehension
      
      // Estimate total duration (rough estimate)
      const totalDuration = text.length / 4; // Slower rate means longer duration
      setProgress({ current: 0, total: totalDuration });
      
      // Events
      firstUtterance.onstart = () => {
        setSpeaking(true);
        startProgressTracking();
      };
      
      firstUtterance.onend = () => {
        if (chunks.length > 0) {
          // If we have more chunks, continue speaking
          const nextChunk = chunks.shift() || "";
          const nextUtterance = new SpeechSynthesisUtterance(nextChunk);
          
          // Copy settings from first utterance
          if (selectedVoice) {
            nextUtterance.voice = selectedVoice.voiceObj;
          }
          nextUtterance.pitch = 1;
          nextUtterance.rate = 0.9;
          
          // Set up chain for next chunk
          nextUtterance.onend = firstUtterance.onend; // Recursive
          window.speechSynthesis.speak(nextUtterance);
        } else {
          // All done
          setSpeaking(false);
          cleanup();
          setProgress(prev => ({ ...prev, current: prev.total }));
        }
      };
      
      firstUtterance.onerror = (event) => {
        console.error("Speech synthesis error:", event);
        setSpeaking(false);
        cleanup();
      };
      
      firstUtterance.onpause = () => {
        setSpeaking(false);
        cleanup();
      };
      
      firstUtterance.onresume = () => {
        setSpeaking(true);
        startProgressTracking();
      };
      
      // Start speaking
      window.speechSynthesis.speak(firstUtterance);
    } catch (error) {
      console.error("Error in text-to-speech:", error);
      setSpeaking(false);
      cleanup();
    }
  };
  
  // Helper function to break text into manageable chunks
  const chunkText = (text: string, size: number): string[] => {
    const chunks: string[] = [];
    let startIndex = 0;
    
    while (startIndex < text.length) {
      // Try to end chunk at a punctuation or space
      let endIndex = Math.min(startIndex + size, text.length);
      
      if (endIndex < text.length) {
        // Look for a good break point
        const possibleBreaks = ['. ', '! ', '? ', '.\n', '!\n', '?\n', '\n\n'];
        let bestBreakPoint = -1;
        
        // Find the last good break point in our chunk
        for (const breakChar of possibleBreaks) {
          const breakPoint = text.lastIndexOf(breakChar, endIndex);
          if (breakPoint > startIndex && breakPoint > bestBreakPoint) {
            bestBreakPoint = breakPoint + breakChar.length - 1; // Include the punctuation
          }
        }
        
        // If no good break found, look for a space
        if (bestBreakPoint === -1) {
          const spaceBreakPoint = text.lastIndexOf(' ', endIndex);
          if (spaceBreakPoint > startIndex) {
            bestBreakPoint = spaceBreakPoint;
          }
        }
        
        // If we found a good break point, use it
        if (bestBreakPoint !== -1) {
          endIndex = bestBreakPoint + 1; // Include the break character
        }
      }
      
      chunks.push(text.substring(startIndex, endIndex));
      startIndex = endIndex;
    }
    
    return chunks;
  };

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      if (speechSynthesis && speaking) {
        speechSynthesis.cancel();
      }
      cleanup();
    };
  }, [speaking]);

  return {
    speak,
    stop,
    speaking,
    progress,
    togglePlayPause,
    availableVoices,
    selectedVoice,
    changeVoice,
    loading
  };
};

export default useTextToSpeech;
